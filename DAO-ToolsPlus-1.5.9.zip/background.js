/**
 * @file Service Worker (background script) для расширения "Interactive PiP".
 * Добавлен режим выбора элемента.
 */
const LOG_NAMESPACE = 'Interactive PiP';
const LOG_LEVEL_ORDER = { error: 0, warn: 1, info: 2, debug: 3 };

function createLogger(scope, level = 'info') {
  const resolveLevel = typeof level === 'function' ? level : () => level;
  const ensureLevel = (value) => (value in LOG_LEVEL_ORDER ? value : 'info');
  const createWriter = (type) => (...args) => {
    const currentLevel = ensureLevel(resolveLevel());
    if (LOG_LEVEL_ORDER[type] > LOG_LEVEL_ORDER[currentLevel]) return;
    const timestamp = new Date().toISOString();
    const writer = console[type] ?? console.log;
    writer(`[${timestamp}] [${LOG_NAMESPACE}] [${scope}]`, ...args);
  };

  return {
    error: createWriter('error'),
    warn: createWriter('warn'),
    info: createWriter('info'),
    debug: createWriter('debug')
  };
}

const log = createLogger('background', 'info');

const TAB_STATE = new Map();
const HEALTH_PERIOD_REQUESTS = new Map();
const CONNECTIONS_SNAPSHOT_REQUESTS = new Map();
const CANCELLED_CONNECTIONS_SNAPSHOT_REQUESTS = new Set();
const SYRVE_TAB_CREDENTIALS = new Map();
const LOYALTY_TAB_CREDENTIALS = new Map();
const GROOVY_LICENSE_RESET_COMPLETIONS = new Map();
const SUPPORTED_PROTOCOLS = new Set(['http:', 'https:', 'file:', 'ftp:']);
const HEALTH_PERIOD_TIMEOUT_MS = 30000;
const CONNECTIONS_SNAPSHOT_TIMEOUT_MS = 30000;
const SYRVE_CREDENTIAL_TTL_MS = 120000;
const HELPDESK_DRAFT_REQUEST_TTL_MS = 5 * 60 * 1000;
const CONNECTIONS_HELPDESK_CONTEXT_TTL_MS = 30 * 60 * 1000;
const STALE_LICENSE_HELPDESK_REQUEST_TTL_MS = 5 * 60 * 1000;
const DAO_SERVICE_STATUS_TIMEOUT_MS = 10000;
const DAO_SERVICE_STATUS_ALARM_NAME = 'dao-service-status-refresh';
const DAO_SERVICE_STATUS_ALARM_PERIOD_MINUTES = 1;
const DAO_SERVICE_STATUS_STALE_MS = 2 * 60 * 1000;
const DEFAULT_ACTION_ICON_PATHS = {
  16: 'icons/icon16.png',
  48: 'icons/icon48.png',
  128: 'icons/icon128.png'
};
const DAO_SERVICE_ACTION_ICON_SIZES = [16, 32, 48];
const DAO_SERVICE_ACTION_ICON_SOURCE_PATHS = {
  16: 'icons/icon16.png',
  32: 'icons/icon48.png',
  48: 'icons/icon48.png'
};
const LOYALTY_PAGE_URL = 'https://loyalty.syrve.live/ru-RU';
const LOYALTY_PASSWORD = 'iikoRMS351';
const DAO_ACCESS_SERVER_BASE_URL = 'https://slm.daolog.net';
const EXTENSION_ACCESS_REQUEST_URL = `${DAO_ACCESS_SERVER_BASE_URL}/extension/access/request`;
const EXTENSION_ACCESS_CLAIM_URL = `${DAO_ACCESS_SERVER_BASE_URL}/extension/access/claim`;
const EXTENSION_ACCESS_STATE_URL = `${DAO_ACCESS_SERVER_BASE_URL}/extension/access/state`;
const CREDENTIALS_LOOKUP_URL = `${DAO_ACCESS_SERVER_BASE_URL}/credentials/lookup`;
const CRM_HANDOFF_URL = `${DAO_ACCESS_SERVER_BASE_URL}/crm/handoff`;
const SERVER_AVAILABILITY_URL = `${DAO_ACCESS_SERVER_BASE_URL}/server/availability`;
const LICENSE_CHECK_URL = `${DAO_ACCESS_SERVER_BASE_URL}/license/check`;
const LICENSE_PRICING_URL = `${DAO_ACCESS_SERVER_BASE_URL}/license/pricing`;
const LICENSE_PRICING_CACHE_TTL_MS = 5 * 60 * 1000;
const LICENSE_UPDATE_URL = `${DAO_ACCESS_SERVER_BASE_URL}/license/update`;
const HELPDESK_DRAFT_URL_BASE = 'https://pro.helpdeskeddy.com/ua/ticket/list/filter/id/352/ticket/create/draft/';
const CONNECTIONS_PATH = '/resto/service/monitoring/connections.jsp';
const GROOVY_MAINTENANCE_PATH = '/resto/service/maintance/groovy.jsp';
const STALE_LICENSE_HELPDESK_ISSUE_TITLE = 'Зависла ліцензія';
const HELPDESK_ATTACHMENT_SESSION_KEY_PREFIX = 'helpDeskDraftAttachment:';
const STALE_LICENSE_REPORT_SESSION_KEY_PREFIX = 'staleLicenseReport:';
const DESKTOP_CAPTURE_PAGE_PATH = 'capture/desktop-capture.html';
const STALE_LICENSE_REPORT_PAGE_PATH = 'capture/stale-license-report.html';
const LICENSE_CALCULATOR_PAGE_PATH = 'calculator/license-calculator.html';
const LICENSE_CALCULATOR_HANDOFF_SESSION_KEY = 'licenseCalculatorHandoff';
const GROOVY_LICENSE_RESET_LOAD_TIMEOUT_MS = 15000;
const GROOVY_LICENSE_RESET_AFTER_SUBMIT_DELAY_MS = 3500;
const GROOVY_LICENSE_RESET_REQUEST_TTL_MS = 2 * 60 * 1000;
const GROOVY_LICENSE_RESET_SESSION_KEY_PREFIX = 'groovyLicenseResetRequest:';
const ALLOWED_STALE_LICENSE_RELEASE_MODULES = new Set([100, 200]);
const COMPANION_STALE_LICENSE_RELEASE_MODULES = new Map([
  [100, [101]]
]);
const FRONT_OFFICE_LICENSE_MODULE_NAMES = new Set([
  'FRONT_OFFICE_FAST_FOOD',
  'FRONT_OFFICE_TABLE_SERVICE'
]);
const BACK_OFFICE_LICENSE_MODULE_NAMES = new Set([
  'BACK_OFFICE',
  'BACKOFFICE',
  'BACK_OFFICE_APP'
]);
const HELPDESK_INLINE_SCREENSHOT_DISPLAY_WIDTH = 1200;
const HELPDESK_INLINE_SCREENSHOT_DISPLAY_HEIGHT = 675;
const STALE_LICENSE_REPORT_MESSAGE_TEXT = [
  '@SergiiBoichuk',
  'Наразі є завислі ліцензії. Прошу перезапустити сервер. Дякую'
].join('\n');
const STORAGE_KEYS = {
  userId: 'userInput',
  legacyApiKey: 'credentialsApiKey',
  extensionClientId: 'extensionClientId',
  extensionRequestId: 'extensionAccessRequestId',
  extensionKey: 'extensionAccessKey',
  extensionScopes: 'extensionAccessScopes',
  bulkModeFormat: 'extensionBulkModeFormat',
  accessNotice: 'extensionAccessNotice',
  daoServiceStatus: 'daoServiceStatus',
  helpDeskDraftRequests: 'helpDeskDraftRequests',
  helpDeskNextDraftNumber: 'helpDeskNextDraftNumber',
  connectionsHelpDeskContexts: 'connectionsHelpDeskContexts',
  staleLicenseHelpDeskRequests: 'staleLicenseHelpDeskRequests'
};
const actionIconBitmapCache = new Map();
// Прайс калькулятора живе лише в пам'яті service worker і лише після авторизованого запиту до SLM.
let licensePricingCache = null;
const daoServiceActionIconCache = new Map();

chrome.runtime.onInstalled.addListener(() => {
  log.info('Extension installed or updated');
  ensureDaoServiceStatusAlarm();
  refreshDaoServiceStatusCache().catch((error) => {
    log.warn('Failed to refresh DAO service status after install/update', { error: error?.message || error });
  });
});

chrome.runtime.onStartup.addListener(() => {
  ensureDaoServiceStatusAlarm();
  refreshDaoServiceStatusCache().catch((error) => {
    log.warn('Failed to refresh DAO service status on browser startup', { error: error?.message || error });
  });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm?.name !== DAO_SERVICE_STATUS_ALARM_NAME) {
    return;
  }

  refreshDaoServiceStatusCache().catch((error) => {
    log.warn('Failed to refresh DAO service status from alarm', { error: error?.message || error });
  });
});

function isSupportedUrl(url) {
  if (!url) {
    log.debug('Tab does not expose URL — skipping PiP toggle');
    return false;
  }
  try {
    const { protocol } = new URL(url);
    const isAllowed = SUPPORTED_PROTOCOLS.has(protocol);
    if (!isAllowed) {
      log.debug('URL protocol is not supported for PiP', { url, protocol });
    }
    return isAllowed;
  } catch (error) {
    log.warn('Unable to parse tab URL — treating as unsupported', { url, error });
    return false;
  }
}

async function requestToggle(tabId, trigger = 'action') {
  log.debug('Sending PiP toggle request', { tabId, trigger });
  try {
    await chrome.tabs.sendMessage(
      tabId,
      {
        command: 'PIP_TOGGLE_REQUEST',
        trigger
      },
      { frameId: 0 }
    );
  } catch (error) {
    const runtimeMessage = chrome.runtime.lastError?.message ?? error?.message;
    log.warn('PiP toggle request failed', { tabId, trigger, error: runtimeMessage });
    chrome.action.setBadgeText({ tabId, text: 'ERR' });
    setTimeout(() => chrome.action.setBadgeText({ tabId, text: '' }), 2500);
  }
}

function storageGet(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, (result) => {
      resolve(result || {});
    });
  });
}

function storageSet(data) {
  return new Promise((resolve) => {
    chrome.storage.local.set(data, () => {
      resolve();
    });
  });
}

function storageRemove(keys) {
  const normalizedKeys = Array.isArray(keys) ? keys.filter(Boolean) : [keys].filter(Boolean);
  if (!normalizedKeys.length) {
    return Promise.resolve();
  }

  return new Promise((resolve) => {
    chrome.storage.local.remove(normalizedKeys, () => {
      resolve();
    });
  });
}

function sessionStorageGet(keys) {
  return new Promise((resolve) => {
    chrome.storage.session.get(keys, (result) => {
      resolve(result || {});
    });
  });
}

function sessionStorageSet(data) {
  return new Promise((resolve) => {
    chrome.storage.session.set(data, () => {
      resolve();
    });
  });
}

function sessionStorageRemove(keys) {
  const normalizedKeys = Array.isArray(keys) ? keys.filter(Boolean) : [keys].filter(Boolean);
  if (!normalizedKeys.length) {
    return Promise.resolve();
  }

  return new Promise((resolve) => {
    chrome.storage.session.remove(normalizedKeys, () => {
      resolve();
    });
  });
}

function normalizeHelpDeskDraftRequestId(value) {
  const normalizedValue = String(value ?? '').trim();
  if (!normalizedValue) {
    throw new Error('Missing HelpDeskEddy draft request id');
  }

  return normalizedValue;
}

function normalizeHelpDeskDraftNumber(value, fallback = 1) {
  const numericValue = Number(value);
  if (!Number.isInteger(numericValue) || numericValue <= 0) {
    return fallback;
  }

  return numericValue;
}

function pruneHelpDeskDraftRequests(rawEntries, now = Date.now()) {
  const sourceEntries = rawEntries && typeof rawEntries === 'object' && !Array.isArray(rawEntries)
    ? rawEntries
    : {};
  const nextEntries = {};
  let wasPruned = sourceEntries !== rawEntries;

  Object.entries(sourceEntries).forEach(([requestId, request]) => {
    if (!request || typeof request !== 'object') {
      wasPruned = true;
      return;
    }

    const createdAt = Number(request.createdAt);
    if (!Number.isFinite(createdAt) || now - createdAt > HELPDESK_DRAFT_REQUEST_TTL_MS) {
      wasPruned = true;
      return;
    }

    nextEntries[requestId] = request;
  });

  if (!wasPruned && Object.keys(nextEntries).length !== Object.keys(sourceEntries).length) {
    wasPruned = true;
  }

  return {
    entries: nextEntries,
    wasPruned
  };
}

async function getHelpDeskDraftRequests() {
  const result = await storageGet(STORAGE_KEYS.helpDeskDraftRequests);
  const { entries, wasPruned } = pruneHelpDeskDraftRequests(result?.[STORAGE_KEYS.helpDeskDraftRequests]);
  if (wasPruned) {
    await storageSet({
      [STORAGE_KEYS.helpDeskDraftRequests]: entries
    });
  }

  return entries;
}

function setHelpDeskDraftRequests(entries) {
  return storageSet({
    [STORAGE_KEYS.helpDeskDraftRequests]: entries
  });
}

function pruneTimedObjectEntries(rawEntries, ttlMs, now = Date.now()) {
  const sourceEntries = rawEntries && typeof rawEntries === 'object' && !Array.isArray(rawEntries)
    ? rawEntries
    : {};
  const nextEntries = {};
  let wasPruned = sourceEntries !== rawEntries;

  Object.entries(sourceEntries).forEach(([key, entry]) => {
    if (!entry || typeof entry !== 'object') {
      wasPruned = true;
      return;
    }

    const createdAt = Number(entry.createdAt);
    if (!Number.isFinite(createdAt) || now - createdAt > ttlMs) {
      wasPruned = true;
      return;
    }

    nextEntries[key] = entry;
  });

  if (!wasPruned && Object.keys(nextEntries).length !== Object.keys(sourceEntries).length) {
    wasPruned = true;
  }

  return {
    entries: nextEntries,
    wasPruned
  };
}

async function getConnectionsHelpDeskContexts() {
  const result = await storageGet(STORAGE_KEYS.connectionsHelpDeskContexts);
  const { entries, wasPruned } = pruneTimedObjectEntries(
    result?.[STORAGE_KEYS.connectionsHelpDeskContexts],
    CONNECTIONS_HELPDESK_CONTEXT_TTL_MS
  );

  if (wasPruned) {
    await storageSet({
      [STORAGE_KEYS.connectionsHelpDeskContexts]: entries
    });
  }

  return entries;
}

function setConnectionsHelpDeskContexts(entries) {
  return storageSet({
    [STORAGE_KEYS.connectionsHelpDeskContexts]: entries
  });
}

async function storeConnectionsHelpDeskContext(tabId, payload, connections = {}) {
  if (tabId === undefined || !payload || typeof payload !== 'object') {
    return;
  }

  const normalizedPath = String(connections.path || '').trim();
  const normalizedServer = normalizeConnectionsHost(connections.server);
  const normalizedPort = normalizePortValue(connections.port);
  const contexts = await getConnectionsHelpDeskContexts();
  contexts[String(tabId)] = {
    createdAt: Date.now(),
    payload,
    server: normalizedServer,
    port: normalizedPort,
    path: normalizedPath,
    url: String(connections.url || '').trim()
  };
  await setConnectionsHelpDeskContexts(contexts);
}

async function getConnectionsHelpDeskContext(tabId) {
  if (tabId === undefined) {
    return null;
  }

  const contexts = await getConnectionsHelpDeskContexts();
  return contexts[String(tabId)] || null;
}

async function removeConnectionsHelpDeskContext(tabId) {
  if (tabId === undefined) {
    return;
  }

  const contexts = await getConnectionsHelpDeskContexts();
  if (!contexts[String(tabId)]) {
    return;
  }

  delete contexts[String(tabId)];
  await setConnectionsHelpDeskContexts(contexts);
}

async function getStaleLicenseHelpDeskRequests() {
  const result = await storageGet(STORAGE_KEYS.staleLicenseHelpDeskRequests);
  const { entries, wasPruned } = pruneTimedObjectEntries(
    result?.[STORAGE_KEYS.staleLicenseHelpDeskRequests],
    STALE_LICENSE_HELPDESK_REQUEST_TTL_MS
  );

  if (wasPruned) {
    await storageSet({
      [STORAGE_KEYS.staleLicenseHelpDeskRequests]: entries
    });
  }

  return entries;
}

function setStaleLicenseHelpDeskRequests(entries) {
  return storageSet({
    [STORAGE_KEYS.staleLicenseHelpDeskRequests]: entries
  });
}

async function setStaleLicenseHelpDeskRequest(requestId, request) {
  const requests = await getStaleLicenseHelpDeskRequests();
  requests[requestId] = request;
  await setStaleLicenseHelpDeskRequests(requests);
}

async function getStaleLicenseHelpDeskRequest(requestId) {
  const requests = await getStaleLicenseHelpDeskRequests();
  return requests[String(requestId || '')] || null;
}

async function removeStaleLicenseHelpDeskRequest(requestId) {
  const requests = await getStaleLicenseHelpDeskRequests();
  if (!requests[String(requestId || '')]) {
    return;
  }

  delete requests[String(requestId || '')];
  await setStaleLicenseHelpDeskRequests(requests);
}

async function removeStaleLicenseHelpDeskRequestsByTabId(tabId) {
  if (tabId === undefined) {
    return;
  }

  const requests = await getStaleLicenseHelpDeskRequests();
  let didChange = false;
  Object.entries(requests).forEach(([requestId, request]) => {
    if (request?.requesterTabId === tabId || request?.captureTabId === tabId) {
      if (request?.captureTabId === tabId && request?.requesterTabId !== tabId) {
        notifyStaleLicenseHelpDeskResult(request.requesterTabId, {
          requestId,
          ok: false,
          error: 'Вкладку створення скріншота закрито до завершення.'
        });
      }

      delete requests[requestId];
      didChange = true;
    }
  });

  if (didChange) {
    await setStaleLicenseHelpDeskRequests(requests);
  }
}

async function getStaleLicenseHelpDeskRequestByRequesterTabId(tabId) {
  if (tabId === undefined) {
    return null;
  }

  const requests = await getStaleLicenseHelpDeskRequests();
  const matchedEntry = Object.entries(requests).find(([, request]) => request?.requesterTabId === tabId);
  if (!matchedEntry) {
    return null;
  }

  const [requestId, request] = matchedEntry;
  return {
    requestId,
    ...request
  };
}

function isConnectionsPath(path) {
  return String(path || '').split(/[?#]/, 1)[0] === CONNECTIONS_PATH;
}

function parseUrl(value) {
  try {
    return new URL(String(value || '').trim());
  } catch (error) {
    return null;
  }
}

function normalizeConnectionsHost(value) {
  return String(value || '').trim().toLowerCase();
}

function normalizePortValue(value) {
  const normalizedValue = String(value || '').trim();
  return /^\d+$/.test(normalizedValue) ? normalizedValue : '';
}

function getEffectiveUrlPort(url) {
  if (!url) {
    return '';
  }

  if (url.port) {
    return url.port;
  }

  if (url.protocol === 'https:') {
    return '443';
  }

  if (url.protocol === 'http:') {
    return '80';
  }

  return '';
}

function isSyrveOnlineSubdomain(hostname) {
  const normalizedHostname = normalizeConnectionsHost(hostname);
  return normalizedHostname.endsWith('.syrve.online') && normalizedHostname !== 'syrve.online';
}

function isSyrveOnlineHost(hostname) {
  const normalizedHostname = normalizeConnectionsHost(hostname);
  return normalizedHostname === 'syrve.online' || normalizedHostname.endsWith('.syrve.online');
}

function isHelpDeskAllowedConnectionsUrl(value) {
  const url = parseUrl(value);
  return Boolean(
    url
    && url.protocol === 'https:'
    && url.pathname === CONNECTIONS_PATH
    && isSyrveOnlineSubdomain(url.hostname)
  );
}

function getContextConnectionsHost(context) {
  const explicitHost = normalizeConnectionsHost(
    context?.server
    || context?.payload?.connectionsServer
    || context?.payload?.server
    || context?.payload?.serverUrl
  );
  if (explicitHost) {
    return explicitHost;
  }

  const contextUrl = parseUrl(context?.url || context?.payload?.connectionsUrl);
  return normalizeConnectionsHost(contextUrl?.hostname);
}

function getContextConnectionsPort(context) {
  const explicitPort = normalizePortValue(
    context?.port
    || context?.payload?.connectionsPort
    || context?.payload?.port
  );
  if (explicitPort) {
    return explicitPort;
  }

  return getEffectiveUrlPort(parseUrl(context?.url || context?.payload?.connectionsUrl));
}

function getContextConnectionsPath(context) {
  return String(context?.path || context?.payload?.connectionsPath || CONNECTIONS_PATH).trim();
}

function assertConnectionsUrlMatchesContext(context, currentUrl) {
  const url = parseUrl(currentUrl);
  if (!url || (url.protocol !== 'http:' && url.protocol !== 'https:') || url.pathname !== CONNECTIONS_PATH) {
    throw new Error('Поточна вкладка не є сторінкою зайнятих ліцензій Syrve.');
  }

  const contextHost = getContextConnectionsHost(context);
  const contextPort = getContextConnectionsPort(context);
  const contextPath = getContextConnectionsPath(context);
  if (!contextHost || !isConnectionsPath(contextPath)) {
    throw new Error('Контекст Planfix для цієї сторінки неповний. Відкрийте її знову кнопкою Зайняті ліцензії.');
  }

  if (normalizeConnectionsHost(url.hostname) !== contextHost) {
    throw new Error('Поточна сторінка зайнятих ліцензій не відповідає серверу з Planfix. Відкрийте її знову кнопкою Зайняті ліцензії.');
  }

  const currentPort = getEffectiveUrlPort(url);
  if (contextPort && currentPort && contextPort !== currentPort) {
    throw new Error('Поточний порт сторінки зайнятих ліцензій не відповідає серверу з Planfix.');
  }

  return url;
}

function assertConnectionsUrlIsValid(currentUrl) {
  const url = parseUrl(currentUrl);
  if (!url || (url.protocol !== 'http:' && url.protocol !== 'https:') || url.pathname !== CONNECTIONS_PATH) {
    throw new Error('Поточна вкладка не є сторінкою зайнятих ліцензій Syrve.');
  }

  return url;
}

function assertConnectionsUrlAllowsGroovyReset(currentUrl) {
  const url = assertConnectionsUrlIsValid(currentUrl);
  if (isSyrveOnlineHost(url.hostname)) {
    throw new Error('Скидання ліцензій через Groovy заборонене для серверів syrve.online.');
  }

  return url;
}

function buildGroovyMaintenanceUrlFromConnectionsUrl(connectionsUrl) {
  return new URL(GROOVY_MAINTENANCE_PATH, `${connectionsUrl.protocol}//${connectionsUrl.host}/`);
}

function normalizeGroovyLicenseResetToken(value) {
  const normalizedValue = String(value || '').trim();
  return /^[a-f0-9-]{16,80}$/i.test(normalizedValue) ? normalizedValue : '';
}

function createGroovyLicenseResetToken() {
  if (globalThis.crypto?.randomUUID) {
    return globalThis.crypto.randomUUID();
  }

  const values = new Uint32Array(4);
  globalThis.crypto?.getRandomValues?.(values);
  return Array.from(values, (value) => value.toString(16).padStart(8, '0')).join('-');
}

function getGroovyLicenseResetSessionKey(token) {
  const normalizedToken = normalizeGroovyLicenseResetToken(token);
  return normalizedToken ? `${GROOVY_LICENSE_RESET_SESSION_KEY_PREFIX}${normalizedToken}` : '';
}

function buildGroovyLicenseResetUrl(groovyUrl, token) {
  const resetUrl = new URL(groovyUrl.toString());
  resetUrl.hash = new URLSearchParams({ daoToolsGroovyReset: token }).toString();
  return resetUrl;
}

function isSameGroovyResetPage(pageUrl, expectedUrl) {
  const actual = parseUrl(pageUrl);
  const expected = parseUrl(expectedUrl);
  return Boolean(
    actual &&
    expected &&
    actual.protocol === expected.protocol &&
    actual.host === expected.host &&
    actual.pathname === expected.pathname
  );
}

async function setGroovyLicenseResetRequest(token, payload) {
  const storageKey = getGroovyLicenseResetSessionKey(token);
  if (!storageKey) {
    throw new Error('Некоректний токен скидання Groovy.');
  }

  await sessionStorageSet({
    [storageKey]: {
      ...payload,
      token,
      createdAt: Date.now()
    }
  });
}

async function getGroovyLicenseResetRequest(token) {
  const storageKey = getGroovyLicenseResetSessionKey(token);
  if (!storageKey) {
    return null;
  }

  const result = await sessionStorageGet(storageKey);
  const request = result?.[storageKey];
  const createdAt = Number(request?.createdAt);
  if (!request || !Number.isFinite(createdAt) || Date.now() - createdAt > GROOVY_LICENSE_RESET_REQUEST_TTL_MS) {
    await sessionStorageRemove(storageKey);
    return null;
  }

  return request;
}

async function removeGroovyLicenseResetRequest(token) {
  const storageKey = getGroovyLicenseResetSessionKey(token);
  if (storageKey) {
    await sessionStorageRemove(storageKey);
  }
}

function waitForGroovyLicenseResetCompletion(token, timeoutMs = GROOVY_LICENSE_RESET_LOAD_TIMEOUT_MS) {
  const normalizedToken = normalizeGroovyLicenseResetToken(token);
  if (!normalizedToken) {
    return Promise.reject(new Error('Некоректний токен скидання Groovy.'));
  }

  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => {
      GROOVY_LICENSE_RESET_COMPLETIONS.delete(normalizedToken);
      reject(new Error('Сторінка Groovy не підтвердила запуск скрипта вчасно.'));
    }, timeoutMs);

    GROOVY_LICENSE_RESET_COMPLETIONS.set(normalizedToken, {
      resolve: (payload) => {
        clearTimeout(timeoutId);
        GROOVY_LICENSE_RESET_COMPLETIONS.delete(normalizedToken);
        resolve(payload);
      },
      reject: (error) => {
        clearTimeout(timeoutId);
        GROOVY_LICENSE_RESET_COMPLETIONS.delete(normalizedToken);
        reject(error);
      }
    });
  });
}

function completeGroovyLicenseReset(token, payload) {
  const normalizedToken = normalizeGroovyLicenseResetToken(token);
  const completion = normalizedToken ? GROOVY_LICENSE_RESET_COMPLETIONS.get(normalizedToken) : null;
  if (!completion) {
    return false;
  }

  completion.resolve(payload);
  return true;
}

async function resolveConnectionsCaptureRoute({ requesterTabId, context, fallbackUrl, forceHelpDesk = false }) {
  const tab = await chrome.tabs.get(requesterTabId);
  const currentUrl = String(tab?.url || fallbackUrl || '').trim();
  const currentConnectionsUrl = assertConnectionsUrlIsValid(currentUrl);
  const isHelpDeskRoute = isHelpDeskAllowedConnectionsUrl(currentConnectionsUrl.toString()) || forceHelpDesk === true;
  const matchedUrl = isHelpDeskRoute
    ? assertConnectionsUrlMatchesContext(context, currentConnectionsUrl.toString())
    : currentConnectionsUrl;

  return {
    sourceConnectionsUrl: matchedUrl.toString(),
    mode: isHelpDeskRoute ? 'helpdesk' : 'report'
  };
}

function normalizeAttachmentStorageKey(value) {
  const normalizedValue = String(value || '').trim();
  return normalizedValue.startsWith(HELPDESK_ATTACHMENT_SESSION_KEY_PREFIX) ? normalizedValue : '';
}

function getHelpDeskAttachmentStorageKeys(payload) {
  return Array.isArray(payload?.attachments)
    ? payload.attachments
      .map((attachment) => normalizeAttachmentStorageKey(attachment?.storageKey))
      .filter(Boolean)
    : [];
}

async function cleanupHelpDeskDraftAttachments(payload) {
  const storageKeys = getHelpDeskAttachmentStorageKeys(payload);
  if (!storageKeys.length) {
    return;
  }

  await sessionStorageRemove(storageKeys);
}

function normalizeStaleLicenseText(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function sanitizeStaleLicenseEntries(licenses) {
  if (!Array.isArray(licenses)) {
    return [];
  }

  return licenses.reduce((result, license) => {
    if (!license || typeof license !== 'object') {
      return result;
    }

    const normalizedLicense = {
      ipAddress: normalizeStaleLicenseText(license.ipAddress),
      computerName: normalizeStaleLicenseText(license.computerName),
      terminalName: normalizeStaleLicenseText(license.terminalName),
      login: normalizeStaleLicenseText(license.login),
      moduleId: normalizeStaleLicenseText(license.moduleId),
      moduleCode: normalizeStaleLicenseText(license.moduleCode),
      moduleName: normalizeStaleLicenseText(license.moduleName),
      moduleDisplayName: normalizeStaleLicenseText(license.moduleDisplayName),
      lastActivity: normalizeStaleLicenseText(license.lastActivity),
      ageLabel: normalizeStaleLicenseText(license.ageLabel)
    };

    if (!normalizedLicense.lastActivity && !normalizedLicense.moduleDisplayName && !normalizedLicense.moduleName) {
      return result;
    }

    result.push(normalizedLicense);
    return result;
  }, []).slice(0, 50);
}

function normalizeModuleLabel(value) {
  return normalizeStaleLicenseText(value).toUpperCase().replace(/[\s-]+/g, '_');
}

function resolveReleaseModuleCodeFromLicense(license) {
  const explicitValues = [
    normalizeStaleLicenseText(license?.moduleCode),
    normalizeStaleLicenseText(license?.moduleId)
  ];

  for (const value of explicitValues) {
    const matchedCode = value.match(/\b(100|200)\b/);
    if (matchedCode) {
      return Number(matchedCode[1]);
    }
  }

  const labels = [
    normalizeModuleLabel(license?.moduleName),
    normalizeModuleLabel(license?.moduleDisplayName)
  ].filter(Boolean);

  if (labels.some((label) => FRONT_OFFICE_LICENSE_MODULE_NAMES.has(label) || (label.includes('FRONT') && label.includes('OFFICE')))) {
    return 100;
  }

  if (labels.some((label) => BACK_OFFICE_LICENSE_MODULE_NAMES.has(label) || (label.includes('BACK') && label.includes('OFFICE')))) {
    return 200;
  }

  return null;
}

function normalizeReleaseModuleCodes(moduleCodes, staleLicenses = []) {
  const result = [];
  const appendCode = (value) => {
    const numericValue = Number(value);
    if (!Number.isInteger(numericValue) || !ALLOWED_STALE_LICENSE_RELEASE_MODULES.has(numericValue)) {
      return;
    }

    if (!result.includes(numericValue)) {
      result.push(numericValue);
    }
  };

  (Array.isArray(moduleCodes) ? moduleCodes : [moduleCodes]).forEach(appendCode);
  staleLicenses.forEach((license) => appendCode(resolveReleaseModuleCodeFromLicense(license)));
  return result;
}

function expandReleaseModuleCodesForGroovy(moduleCodes) {
  const result = [];
  const appendCode = (value) => {
    const numericValue = Number(value);
    if (!Number.isInteger(numericValue) || result.includes(numericValue)) {
      return;
    }

    result.push(numericValue);
  };

  normalizeReleaseModuleCodes(moduleCodes).forEach((moduleCode) => {
    appendCode(moduleCode);
    (COMPANION_STALE_LICENSE_RELEASE_MODULES.get(moduleCode) || []).forEach(appendCode);
  });

  return result;
}

function buildGroovyLicenseResetScript(moduleCodes) {
  const groovyReleaseCodes = expandReleaseModuleCodesForGroovy(moduleCodes);
  if (!groovyReleaseCodes.length) {
    throw new Error('Не вдалося визначити модуль ліцензії для скидання.');
  }

  return [
    'import resto.licensing.LicenseService;',
    ...groovyReleaseCodes.map((moduleCode) => `LicenseService.releaseModuleConnections(${moduleCode});`)
  ].join('\n');
}

function buildStaleLicenseDescription(payload) {
  const baseDescription = String(payload?.description || '').trim();
  const lines = baseDescription ? baseDescription.split('\n') : [
    'Добрий день колеги!',
    `Company: ${String(payload?.clientName || '').trim()}`,
    `CrmOrganizationId: ${String(payload?.crmId || '').trim()}`,
    `SerialNumber: ${String(payload?.uid || '').trim()}`,
    `v. Syrve: ${String(payload?.version || '').trim()}`
  ];

  lines.push('');
  lines.push('Допоможіть будь ласка. Зависла ліцензія');

  return lines.join('\n');
}

function buildStaleLicenseHelpDeskPayload({ basePayload, sourceConnectionsUrl, staleLicenses, attachment }) {
  const restaurantName = String(basePayload?.restaurantName || '').trim() || '—';
  const nextPayload = {
    ...basePayload,
    issueTitle: STALE_LICENSE_HELPDESK_ISSUE_TITLE,
    title: `${restaurantName}: ${STALE_LICENSE_HELPDESK_ISSUE_TITLE}`,
    sourceConnectionsUrl: String(sourceConnectionsUrl || '').trim(),
    staleLicenses,
    attachments: attachment ? [attachment] : []
  };

  nextPayload.description = buildStaleLicenseDescription(nextPayload);
  return nextPayload;
}

function notifyStaleLicenseHelpDeskResult(tabId, payload) {
  if (tabId === undefined) {
    return;
  }

  chrome.tabs.sendMessage(tabId, {
    action: 'STALE_LICENSE_HELPDESK_REQUEST_RESULT',
    ...payload
  }).catch((error) => {
    log.warn('Failed to deliver stale license HelpDesk result', {
      tabId,
      error: error?.message
    });
  });
}

function createScreenshotFileName(now = new Date()) {
  const timestamp = now.toISOString()
    .replace(/\.\d{3}Z$/, '')
    .replace(/:/g, '-')
    .replace('T', '_');
  return `stale-license-connections-${timestamp}.jpg`;
}

function buildStaleLicenseReportUrl(reportId) {
  const url = new URL(chrome.runtime.getURL(STALE_LICENSE_REPORT_PAGE_PATH));
  url.hash = new URLSearchParams({ reportId }).toString();
  return url.toString();
}

function getServerLabelFromConnectionsUrl(value) {
  const url = parseUrl(value);
  if (!url) {
    return '';
  }

  return `${url.protocol}//${url.host}`;
}

function buildStaleLicenseReportPayload({ basePayload, sourceConnectionsUrl, staleLicenses, screenshot }) {
  return {
    createdAt: Date.now(),
    messageText: STALE_LICENSE_REPORT_MESSAGE_TEXT,
    sourceConnectionsUrl: String(sourceConnectionsUrl || '').trim(),
    restaurantName: String(basePayload?.restaurantName || '').trim(),
    server: getServerLabelFromConnectionsUrl(sourceConnectionsUrl),
    port: '',
    staleLicenses,
    screenshot
  };
}

async function openStaleLicenseReportTab({ requesterTabId, payload, active = true }) {
  if (requesterTabId === undefined) {
    throw new Error('Missing requester tab id');
  }

  if (!payload || typeof payload !== 'object') {
    throw new Error('Missing stale license report payload');
  }

  const reportId = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  const storageKey = `${STALE_LICENSE_REPORT_SESSION_KEY_PREFIX}${reportId}`;
  await sessionStorageSet({
    [storageKey]: payload
  });

  const requesterTab = await chrome.tabs.get(requesterTabId).catch(() => null);
  const createProperties = {
    url: buildStaleLicenseReportUrl(reportId),
    active
  };

  if (requesterTab?.windowId !== undefined) {
    createProperties.windowId = requesterTab.windowId;
  }

  try {
    const createdTab = await chrome.tabs.create(createProperties);
    if (createdTab.id === undefined) {
      throw new Error('Сторінку повідомлення створено без id.');
    }

    return {
      reportId,
      tabId: createdTab.id,
      storageKey
    };
  } catch (error) {
    await sessionStorageRemove(storageKey);
    throw error;
  }
}

function normalizeLicenseCalculatorTheme(value) {
  return value === 'dark' || value === 'light' ? value : '';
}

async function openLicenseCalculatorTab({ server, port, result, chain, theme, windowId }) {
  const normalizedServer = String(server ?? '').trim();
  const normalizedPort = String(port ?? '').trim();
  const normalizedTheme = normalizeLicenseCalculatorTheme(theme);
  const params = new URLSearchParams();

  if (normalizedServer) {
    params.set('server', normalizedServer);
    if (normalizedPort) {
      params.set('port', normalizedPort);
    }
  }

  if (normalizedTheme) {
    params.set('theme', normalizedTheme);
  }

  // Контекст картки потрібен і для прямого відкриття; готові ліцензії — лише з модалки.
  if (normalizedServer) {
    const handoffId = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    await sessionStorageSet({
      [LICENSE_CALCULATOR_HANDOFF_SESSION_KEY]: {
        id: handoffId,
        createdAt: Date.now(),
        context: {
          server: normalizedServer,
          port: normalizedPort,
          chain: String(chain ?? '').trim().slice(0, 300)
        },
        result: result && typeof result === 'object' ? {
          server: sanitizeLicenseCheckServer(result.server),
          licenses: sanitizeLicenseCheckLicenses(result.licenses)
        } : null
      }
    });
    params.set('handoff', handoffId);
  }

  const pageUrl = chrome.runtime.getURL(LICENSE_CALCULATOR_PAGE_PATH);
  const hash = params.toString();
  const targetUrl = hash ? `${pageUrl}#${hash}` : pageUrl;
  const [existingTab] = await chrome.tabs.query({ url: pageUrl }).catch(() => []);

  if (existingTab?.id !== undefined) {
    const updateProperties = { active: true };
    // Лише hash-навігація: перехід без hash перезавантажив би сторінку й скинув розрахунок.
    if (hash && existingTab.url !== targetUrl) {
      updateProperties.url = targetUrl;
    }

    await chrome.tabs.update(existingTab.id, updateProperties);
    await chrome.windows.update(existingTab.windowId, { focused: true }).catch(() => {});
    return { tabId: existingTab.id, reused: true };
  }

  const createProperties = { url: targetUrl, active: true };
  if (windowId !== undefined) {
    createProperties.windowId = windowId;
  }

  const createdTab = await chrome.tabs.create(createProperties);
  return { tabId: createdTab.id, reused: false };
}

async function reserveHelpDeskDraftNumber(existingRequests = null) {
  const requests = existingRequests || await getHelpDeskDraftRequests();
  const storedState = await storageGet(STORAGE_KEYS.helpDeskNextDraftNumber);
  const storedDraftNumber = normalizeHelpDeskDraftNumber(storedState?.[STORAGE_KEYS.helpDeskNextDraftNumber], 1);
  const highestActiveDraftNumber = Object.values(requests).reduce((maxDraftNumber, request) => {
    return Math.max(maxDraftNumber, normalizeHelpDeskDraftNumber(request?.draftNumber, 0));
  }, 0);

  const draftNumber = Math.max(storedDraftNumber, highestActiveDraftNumber + 1, 1);
  await storageSet({
    [STORAGE_KEYS.helpDeskNextDraftNumber]: draftNumber + 1
  });

  return draftNumber;
}

function buildHelpDeskDraftUrl(requestId, draftNumber) {
  const normalizedDraftNumber = normalizeHelpDeskDraftNumber(draftNumber, 1);
  const url = new URL(`${HELPDESK_DRAFT_URL_BASE}${normalizedDraftNumber}`);
  url.hash = new URLSearchParams({
    'dao-tools-request': requestId
  }).toString();
  return url.toString();
}

async function openHelpDeskDraftTab({ requesterTabId, payload, active = true }) {
  if (requesterTabId === undefined) {
    throw new Error('Missing requester tab id');
  }

  if (!payload || typeof payload !== 'object') {
    throw new Error('Missing HelpDeskEddy draft payload');
  }

  const requestId = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  const requests = await getHelpDeskDraftRequests();
  const draftNumber = await reserveHelpDeskDraftNumber(requests);
  const createdTab = await chrome.tabs.create({
    url: buildHelpDeskDraftUrl(requestId, draftNumber),
    active
  });

  if (createdTab.id === undefined) {
    throw new Error('HelpDeskEddy tab was created without an id');
  }

  requests[requestId] = {
    createdAt: Date.now(),
    requesterTabId,
    targetTabId: createdTab.id,
    draftNumber,
    payload
  };

  await setHelpDeskDraftRequests(requests);
  log.info('Opened HelpDeskEddy draft tab', {
    requesterTabId,
    targetTabId: createdTab.id,
    requestId,
    draftNumber
  });

  return {
    requestId,
    tabId: createdTab.id,
    draftNumber
  };
}

async function getHelpDeskDraftRequest(requestId) {
  const normalizedRequestId = normalizeHelpDeskDraftRequestId(requestId);
  const requests = await getHelpDeskDraftRequests();
  const request = requests[normalizedRequestId] ?? null;
  if (!request) {
    return null;
  }

  return {
    requestId: normalizedRequestId,
    ...request
  };
}

async function getHelpDeskDraftRequestByTabId(tabId) {
  if (tabId === undefined) {
    return null;
  }

  const requests = await getHelpDeskDraftRequests();
  const matchedEntry = Object.entries(requests).find(([, request]) => request?.targetTabId === tabId);
  if (!matchedEntry) {
    return null;
  }

  const [requestId, request] = matchedEntry;
  return {
    requestId,
    ...request
  };
}

async function getHelpDeskDraftRequestByRequesterTabId(tabId) {
  if (tabId === undefined) {
    return null;
  }

  const requests = await getHelpDeskDraftRequests();
  const matchedEntry = Object.entries(requests).find(([, request]) => request?.requesterTabId === tabId);
  if (!matchedEntry) {
    return null;
  }

  const [requestId, request] = matchedEntry;
  return {
    requestId,
    ...request
  };
}

function notifyHelpDeskDraftResult(requesterTabId, payload) {
  if (requesterTabId === undefined) {
    return;
  }

  chrome.tabs.sendMessage(requesterTabId, {
    action: 'HELPDESK_DRAFT_FILL_RESULT',
    ...payload
  }).catch((error) => {
    log.warn('Failed to deliver HelpDeskEddy draft result to PlanFix tab', {
      requesterTabId,
      error: error?.message
    });
  });
}

async function finalizeHelpDeskDraftRequest({ requestId, ok, error, sourceTabId }) {
  const normalizedRequestId = normalizeHelpDeskDraftRequestId(requestId);
  const requests = await getHelpDeskDraftRequests();
  const request = requests[normalizedRequestId];
  if (!request) {
    return false;
  }

  await cleanupHelpDeskDraftAttachments(request.payload);
  delete requests[normalizedRequestId];
  await setHelpDeskDraftRequests(requests);
  notifyHelpDeskDraftResult(request.requesterTabId, {
    requestId: normalizedRequestId,
    ok,
    error,
    helpdeskTabId: request.targetTabId ?? sourceTabId
  });

  const logMethod = ok ? 'info' : 'warn';
  log[logMethod]('Finalized HelpDeskEddy draft request', {
    requestId: normalizedRequestId,
    requesterTabId: request.requesterTabId,
    targetTabId: request.targetTabId ?? sourceTabId,
    ok,
    error
  });
  return true;
}

async function resolveClosedHelpDeskDraftTab(tabId) {
  const requests = await getHelpDeskDraftRequests();
  let didChange = false;

  const attachmentCleanupTasks = [];

  Object.entries(requests).forEach(([requestId, request]) => {
    if (request?.targetTabId !== tabId) {
      return;
    }

    attachmentCleanupTasks.push(cleanupHelpDeskDraftAttachments(request.payload));
    delete requests[requestId];
    didChange = true;
    notifyHelpDeskDraftResult(request.requesterTabId, {
      requestId,
      ok: false,
      error: 'Вкладку чернетки HelpDeskEddy закрито до завершення автозаповнення.',
      helpdeskTabId: tabId
    });
  });

  if (didChange) {
    await Promise.allSettled(attachmentCleanupTasks);
    await setHelpDeskDraftRequests(requests);
  }
}

async function readJsonResponse(response) {
  try {
    return await response.json();
  } catch (error) {
    return null;
  }
}

function extractServerMessage(payload) {
  if (typeof payload?.error === 'string' && payload.error.trim()) {
    return payload.error.trim();
  }

  if (typeof payload?.message === 'string' && payload.message.trim()) {
    return payload.message.trim();
  }

  return '';
}

function normalizeUserId(value) {
  const normalizedValue = String(value ?? '').trim();

  if (!normalizedValue) {
    throw new Error('Вкажіть User ID у popup розширення.');
  }

  if (!/^\d+$/.test(normalizedValue)) {
    throw new Error('User ID має містити лише цифри.');
  }

  return normalizedValue;
}

function normalizeCredentialId(value) {
  return Number(normalizeUserId(value));
}

function buildCredentialsLookupErrorMessage(status, payload) {
  const serverMessage = extractServerMessage(payload);

  switch (status) {
    case 400:
      return serverMessage || 'Сервер credentials відхилив User ID. Перевірте, що він числовий.';
    case 401:
      return 'Розширення не передало X-Extension-Key для отримання логіна та пароля. Завершіть доступ пристрою у popup.';
    case 403:
      return 'Персональний доступ цього пристрою до credentials недійсний або відкликаний. Попросіть адміністратора видати новий код підтвердження.';
    case 404:
      return 'Для цього User ID не знайдено логін і пароль.';
    case 503:
      return 'Сервер credentials не налаштований.';
    case 500:
      return 'Сервер credentials повернув внутрішню помилку.';
    default:
      return serverMessage || `Сервер credentials повернув помилку зі статусом ${status}.`;
  }
}

function normalizeProtectedServerAddress(value, errorMessage) {
  const normalizedValue = String(value ?? '').trim();
  if (!normalizedValue || /\s/.test(normalizedValue) || normalizedValue.includes('://') || /[/?#@]/.test(normalizedValue)) {
    throw new Error(errorMessage);
  }

  return normalizedValue;
}

function normalizeProtectedServerPort(value, invalidMessage, outOfRangeMessage) {
  const normalizedValue = String(value ?? '').trim();
  if (!/^\d+$/.test(normalizedValue)) {
    throw new Error(invalidMessage);
  }

  const parsedPort = Number(normalizedValue);
  if (!Number.isInteger(parsedPort) || parsedPort < 1 || parsedPort > 65535) {
    throw new Error(outOfRangeMessage);
  }

  return parsedPort;
}

function normalizeLicenseServerAddress(value) {
  return normalizeProtectedServerAddress(value, 'Некоректна адреса сервера для перевірки ліцензій.');
}

function normalizeLicenseServerPort(value) {
  return normalizeProtectedServerPort(
    value,
    'Некоректний порт сервера для перевірки ліцензій.',
    'Порт сервера для перевірки ліцензій має бути в межах від 1 до 65535.'
  );
}

function normalizeServerAvailabilityAddress(value) {
  return normalizeProtectedServerAddress(value, 'Некоректна адреса сервера для перевірки доступності сервера.');
}

function normalizeServerAvailabilityPort(value) {
  return normalizeProtectedServerPort(
    value,
    'Некоректний порт сервера для перевірки доступності сервера.',
    'Порт сервера для перевірки доступності сервера має бути в межах від 1 до 65535.'
  );
}

function normalizeCardWebUrl(value) {
  const normalizedValue = String(value ?? '').trim();
  if (!normalizedValue) {
    throw new Error('Поле Web: посилання порожнє або відсутнє.');
  }

  let parsedUrl;
  try {
    parsedUrl = new URL(normalizedValue);
  } catch (error) {
    throw new Error('Поле Web: посилання містить некоректну адресу.');
  }

  if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
    throw new Error('Поле Web: посилання має містити http або https адресу.');
  }

  return parsedUrl.toString();
}

function normalizeCrmHandoffSyrveWebUrl(value) {
  const normalizedValue = String(value ?? '').trim();
  if (!normalizedValue) {
    throw new Error('Не вказано адресу Syrve Web для переходу в довідники.');
  }

  let parsedUrl;
  try {
    parsedUrl = new URL(
      normalizedValue.includes('://') ? normalizedValue : `https://${normalizedValue}`
    );
  } catch (error) {
    throw new Error('Адреса Syrve Web для переходу в довідники некоректна.');
  }

  const hostname = parsedUrl.hostname.toLowerCase();
  if (
    parsedUrl.protocol !== 'https:'
    || hostname === 'syrve.app'
    || !hostname.endsWith('.syrve.app')
    || parsedUrl.username
    || parsedUrl.password
    || parsedUrl.search
    || parsedUrl.hash
    || (parsedUrl.pathname && parsedUrl.pathname !== '/')
    || (parsedUrl.port && parsedUrl.port !== '443')
  ) {
    throw new Error('Для переходу в довідники потрібна адреса у форматі 867-404-806.syrve.app.');
  }

  return hostname;
}

function normalizeCrmHandoffConnectUrl(value) {
  let parsedUrl;
  try {
    parsedUrl = new URL(String(value ?? '').trim());
  } catch (error) {
    throw new Error('SLM повернув некоректне посилання для переходу в довідники.');
  }

  if (
    parsedUrl.origin !== 'https://api.daolog.net'
    || parsedUrl.pathname !== '/connect'
    || !parsedUrl.searchParams.get('ticket')
    || parsedUrl.username
    || parsedUrl.password
    || parsedUrl.hash
  ) {
    throw new Error('SLM повернув неочікуване посилання для переходу в довідники.');
  }

  return parsedUrl.toString();
}

function buildCrmHandoffErrorMessage(status, payload) {
  const serverMessage = extractServerMessage(payload);

  switch (status) {
    case 400:
      return serverMessage || 'SLM відхилив адресу Syrve Web для переходу в довідники.';
    case 401:
      return 'Розширення не передало X-Extension-Key для переходу в довідники. Завершіть доступ пристрою у popup.';
    case 403:
      return 'Персональний доступ цього пристрою до переходу в довідники недійсний або відкликаний.';
    case 404:
      return 'Для цього користувача не знайдено активну учётку.';
    case 422:
      return 'Зовнішній сервіс відхилив усі активні учётки цього користувача.';
    case 502:
      if (Number(payload?.upstreamStatus) === 401) {
        return 'Зовнішній сервіс відхилив sourceKey, логін або пароль (401).';
      }
      return 'Зовнішній сервіс переходу в довідники недоступний або повернув некоректну відповідь.';
    case 503:
      return 'Перехід у довідники не налаштований на SLM.';
    case 504:
      return 'Зовнішній сервіс переходу в довідники не відповів вчасно.';
    default:
      return serverMessage || `SLM повернув помилку переходу в довідники зі статусом ${status}.`;
  }
}

function buildLicenseCheckErrorMessage(status, payload) {
  const serverMessage = extractServerMessage(payload);

  switch (status) {
    case 400:
      return serverMessage || 'Сервер license check відхилив адресу або порт.';
    case 401:
      return 'Розширення не передало X-Extension-Key для перевірки ліцензій. Завершіть доступ пристрою у popup.';
    case 403:
      return 'Персональний доступ цього пристрою до license check недійсний або відкликаний. Попросіть адміністратора видати новий код підтвердження.';
    case 500:
      return 'Сервер license check не налаштований або має внутрішню помилку.';
    case 502:
      return 'Syrve повернув некоректну відповідь або недоступний для перевірки.';
    case 504:
      return 'Syrve не відповів вчасно на перевірку ліцензій.';
    default:
      return serverMessage || `Сервер license check повернув помилку зі статусом ${status}.`;
  }
}

function buildServerAvailabilityErrorMessage(status, payload) {
  const serverMessage = extractServerMessage(payload);

  switch (status) {
    case 400:
      return serverMessage || 'Сервер перевірки доступності відхилив адресу або порт.';
    case 401:
      return 'Розширення не передало X-Extension-Key для перевірки доступності сервера. Завершіть доступ пристрою у popup.';
    case 403:
      return 'Персональний доступ цього пристрою до перевірки доступності сервера недійсний або відкликаний. Попросіть адміністратора видати новий код підтвердження.';
    case 500:
      return 'Сервер перевірки доступності не налаштований або має внутрішню помилку.';
    default:
      return serverMessage || `Сервер перевірки доступності повернув помилку зі статусом ${status}.`;
  }
}

function buildLicenseUpdateErrorMessage(status, payload) {
  const serverMessage = extractServerMessage(payload);

  switch (status) {
    case 400:
      return serverMessage || 'Сервер оновлення ліцензій відхилив адресу, порт або UID.';
    case 401:
      return 'Розширення не передало X-Extension-Key для оновлення ліцензій. Завершіть доступ пристрою у popup.';
    case 403:
      return 'Для цього пристрою не видано право на масове оновлення ліцензій. Увімкніть його в Users розділі SLM і перевидайте доступ пристрою.';
    case 500:
      return 'Сервер оновлення ліцензій не налаштований або має внутрішню помилку.';
    case 502:
      return 'Syrve повернув некоректну відповідь під час оновлення ліцензій.';
    case 504:
      return 'Syrve не відповів вчасно на оновлення ліцензій.';
    default:
      return serverMessage || `Сервер оновлення ліцензій повернув помилку зі статусом ${status}.`;
  }
}

function sanitizeLicenseUpdateDiffSummary(diffSummary) {
  if (!diffSummary || typeof diffSummary !== 'object') {
    return null;
  }

  const normalizedSummary = {
    newLicenses: Number.isFinite(Number(diffSummary.newLicenses)) ? Number(diffSummary.newLicenses) : 0,
    changedValidUntil: Number.isFinite(Number(diffSummary.changedValidUntil)) ? Number(diffSummary.changedValidUntil) : 0,
    changedCount: Number.isFinite(Number(diffSummary.changedCount)) ? Number(diffSummary.changedCount) : 0
  };

  return normalizedSummary;
}

function sanitizeLicenseValidityValue(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

function sanitizeLicenseUpdateLicenses(licenses) {
  if (!Array.isArray(licenses)) {
    return [];
  }

  return licenses.reduce((result, license) => {
    if (!license || typeof license !== 'object') {
      return result;
    }

    const id = typeof license.id === 'string' || typeof license.id === 'number'
      ? String(license.id).trim()
      : '';
    const name = typeof license.name === 'string' ? license.name.trim() : '';
    const friendlyName = typeof license.friendlyName === 'string' ? license.friendlyName.trim() : '';
    const groupId = typeof license.groupId === 'string' && license.groupId.trim()
      ? license.groupId.trim()
      : 'other';
    const groupTitle = typeof license.groupTitle === 'string' && license.groupTitle.trim()
      ? license.groupTitle.trim()
      : '';
    const countBeforeValue = Number(license.countBefore);
    const countAfterValue = Number(license.countAfter);
    const validUntilBefore = sanitizeLicenseValidityValue(license.validUntilBefore) || '';
    const validUntilAfter = sanitizeLicenseValidityValue(license.validUntilAfter) || '';

    if (!id && !name && !friendlyName) {
      return result;
    }

    result.push({
      id,
      name,
      friendlyName,
      groupId,
      groupTitle,
      availableBefore: license.availableBefore === true,
      availableAfter: license.availableAfter === true,
      countBefore: Number.isFinite(countBeforeValue) ? countBeforeValue : null,
      countAfter: Number.isFinite(countAfterValue) ? countAfterValue : null,
      validUntilBefore,
      validUntilAfter,
      validUntil: validUntilAfter || validUntilBefore || ''
    });

    return result;
  }, []);
}

function extractRequestId(payload) {
  return String(payload?.request?.requestId ?? payload?.requestId ?? '').trim();
}

function buildAccessRequestErrorMessage(status, payload) {
  const serverMessage = extractServerMessage(payload);

  switch (status) {
    case 400:
      return serverMessage || 'Сервер доступу відхилив User ID або дані пристрою.';
    default:
      return serverMessage || `Сервер доступу повернув помилку зі статусом ${status}.`;
  }
}

function buildAccessClaimErrorMessage(status, payload) {
  const serverMessage = extractServerMessage(payload);

  switch (status) {
    case 400:
      return serverMessage || 'Request ID або код підтвердження мають некоректний формат.';
    case 403:
      return 'Код підтвердження неправильний. Перевірте код або зверніться до адміністратора.';
    case 404:
      return 'Запит доступу не знайдено. Спробуйте запросити доступ для пристрою ще раз.';
    case 409:
      return 'Пристрій ще не схвалено в адмінці. Дочекайтеся підтвердження адміністратора.';
    case 410:
      return 'Код підтвердження прострочений або вже використаний. Попросіть адміністратора видати новий код.';
    default:
      return serverMessage || `Сервер claim повернув помилку зі статусом ${status}.`;
  }
}

function buildAccessRequestNotice(status) {
  if (status === 200) {
    return 'Запит для цього пристрою знайдено. Якщо адміністратор уже видав код підтвердження, введіть його у popup.';
  }

  return 'Запит на доступ до пристрою збережено. Після ручного схвалення введіть код підтвердження у popup.';
}

function shouldClearInvalidExtensionAccess(payload) {
  return payload?.errorCode !== 'invalid-extension-scope';
}

function normalizeExtensionAccessScopes(value) {
  if (!Array.isArray(value)) {
    return [];
  }

  const seen = new Set();
  return value.reduce((result, scope) => {
    const normalizedScope = typeof scope === 'string' ? scope.trim() : '';
    if (!normalizedScope || seen.has(normalizedScope)) {
      return result;
    }

    seen.add(normalizedScope);
    result.push(normalizedScope);
    return result;
  }, []);
}

function hasBulkLicenseAccess(scopes) {
  return normalizeExtensionAccessScopes(scopes).includes('license.bulk');
}

function normalizeBulkModeFormat(value) {
  return String(value ?? '').trim().toLowerCase() === 'inline' ? 'inline' : 'legacy';
}

function extractExtensionAccessScopes(payload) {
  return normalizeExtensionAccessScopes(payload?.access?.scopes || payload?.request?.scopes);
}

async function removeStoredExtensionAccessScope(scopeToRemove) {
  const normalizedScope = typeof scopeToRemove === 'string' ? scopeToRemove.trim() : '';
  if (!normalizedScope) {
    return;
  }

  const storageData = await storageGet([STORAGE_KEYS.extensionScopes]);
  const nextScopes = normalizeExtensionAccessScopes(storageData?.[STORAGE_KEYS.extensionScopes])
    .filter((scope) => scope !== normalizedScope);

  await storageSet({
    [STORAGE_KEYS.extensionScopes]: nextScopes
  });
}

function getBrowserLabel() {
  const userAgent = navigator.userAgent || '';

  if (/Edg\//.test(userAgent)) return 'Edge';
  if (/Chrome\//.test(userAgent)) return 'Chrome';
  if (/Firefox\//.test(userAgent)) return 'Firefox';
  if (/Safari\//.test(userAgent) && !/Chrome\//.test(userAgent)) return 'Safari';

  return 'Browser';
}

function getDeviceName() {
  const platform = navigator.userAgentData?.platform || navigator.platform || 'Unknown device';
  return `${getBrowserLabel()} on ${platform}`;
}

function buildExtensionAccessState(storageData) {
  const userId = String(storageData?.[STORAGE_KEYS.userId] ?? '').trim();
  const clientId = String(storageData?.[STORAGE_KEYS.extensionClientId] ?? '').trim();
  const requestId = String(storageData?.[STORAGE_KEYS.extensionRequestId] ?? '').trim();
  const extensionKey = String(storageData?.[STORAGE_KEYS.extensionKey] ?? '').trim();
  const scopes = normalizeExtensionAccessScopes(storageData?.[STORAGE_KEYS.extensionScopes]);
  const bulkModeFormat = normalizeBulkModeFormat(storageData?.[STORAGE_KEYS.bulkModeFormat]);
  const notice = String(storageData?.[STORAGE_KEYS.accessNotice] ?? '').trim();

  let status = 'needs-user';
  if (userId) {
    status = extensionKey ? 'granted' : requestId ? 'awaiting-claim' : 'ready-to-request';
  }

  return {
    status,
    userId,
    clientId,
    requestId,
    hasExtensionKey: Boolean(extensionKey),
    scopes,
    hasBulkLicenseAccess: Boolean(extensionKey) && hasBulkLicenseAccess(scopes),
    bulkModeFormat,
    notice
  };
}

async function getExtensionAccessState(options = {}) {
  const { refreshRemote = true } = options;
  const storageData = await storageGet([
    STORAGE_KEYS.userId,
    STORAGE_KEYS.extensionClientId,
    STORAGE_KEYS.extensionRequestId,
    STORAGE_KEYS.extensionKey,
    STORAGE_KEYS.extensionScopes,
    STORAGE_KEYS.bulkModeFormat,
    STORAGE_KEYS.accessNotice
  ]);

  const localState = buildExtensionAccessState(storageData);

  if (!refreshRemote || !localState.hasExtensionKey) {
    return localState;
  }

  try {
    const remoteAccessState = await fetchRemoteExtensionAccessState();
    const remoteScopes = normalizeExtensionAccessScopes(remoteAccessState?.scopes);
    const bulkModeFormat = normalizeBulkModeFormat(remoteAccessState?.bulkModeFormat);
    await storageSet({
      [STORAGE_KEYS.extensionScopes]: remoteScopes,
      [STORAGE_KEYS.bulkModeFormat]: bulkModeFormat
    });

    return buildExtensionAccessState({
      ...storageData,
      [STORAGE_KEYS.extensionScopes]: remoteScopes,
      [STORAGE_KEYS.bulkModeFormat]: bulkModeFormat
    });
  } catch (error) {
    const fallbackStorageData = await storageGet([
      STORAGE_KEYS.userId,
      STORAGE_KEYS.extensionClientId,
      STORAGE_KEYS.extensionRequestId,
      STORAGE_KEYS.extensionKey,
      STORAGE_KEYS.extensionScopes,
      STORAGE_KEYS.bulkModeFormat,
      STORAGE_KEYS.accessNotice
    ]);

    return buildExtensionAccessState(fallbackStorageData);
  }
}

function clearAllSyrveCredentials() {
  SYRVE_TAB_CREDENTIALS.clear();
}

async function saveUserId(rawUserId) {
  const userId = normalizeUserId(rawUserId);
  const storageData = await storageGet([STORAGE_KEYS.userId]);
  const previousUserId = String(storageData[STORAGE_KEYS.userId] ?? '').trim();
  const hasChanged = previousUserId !== userId;

  await storageSet({
    [STORAGE_KEYS.userId]: userId
  });

  const keysToRemove = [STORAGE_KEYS.legacyApiKey];
  if (hasChanged) {
    keysToRemove.push(
      STORAGE_KEYS.extensionRequestId,
      STORAGE_KEYS.extensionKey,
      STORAGE_KEYS.extensionScopes,
      STORAGE_KEYS.bulkModeFormat,
      STORAGE_KEYS.accessNotice
    );
  }

  await storageRemove([...new Set(keysToRemove)]);

  if (hasChanged) {
    clearAllSyrveCredentials();
  }

  if (previousUserId && hasChanged) {
    await storageSet({
      [STORAGE_KEYS.accessNotice]: 'User ID змінено. Для цього пристрою потрібно запросити доступ повторно.'
    });
  }

  return getExtensionAccessState();
}

async function getOrCreateClientId() {
  const storageData = await storageGet([STORAGE_KEYS.extensionClientId]);
  const storedClientId = String(storageData[STORAGE_KEYS.extensionClientId] ?? '').trim();

  if (storedClientId) {
    return storedClientId;
  }

  const clientId = crypto.randomUUID();
  await storageSet({
    [STORAGE_KEYS.extensionClientId]: clientId
  });

  return clientId;
}

async function requestExtensionAccess(rawUserId) {
  let userId = '';
  if (rawUserId !== undefined) {
    const nextState = await saveUserId(rawUserId);
    userId = nextState.userId;
  } else {
    const storageData = await storageGet([STORAGE_KEYS.userId]);
    userId = normalizeUserId(storageData[STORAGE_KEYS.userId]);
  }

  const clientId = await getOrCreateClientId();
  const deviceName = getDeviceName();
  let response;

  try {
    response = await fetch(EXTENSION_ACCESS_REQUEST_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        userId,
        clientId,
        deviceName
      })
    });
  } catch (error) {
    throw new Error('Не вдалося звернутися до сервера доступу. Перевірте мережу та доступність сервера.');
  }

  const payload = await readJsonResponse(response);
  if (!response.ok) {
    throw new Error(buildAccessRequestErrorMessage(response.status, payload));
  }

  const requestId = extractRequestId(payload);
  if (!requestId) {
    throw new Error('Сервер доступу не повернув requestId.');
  }

  await storageSet({
    [STORAGE_KEYS.extensionClientId]: clientId,
    [STORAGE_KEYS.extensionRequestId]: requestId,
    [STORAGE_KEYS.extensionScopes]: extractExtensionAccessScopes(payload),
    [STORAGE_KEYS.accessNotice]: buildAccessRequestNotice(response.status)
  });
  await storageRemove([STORAGE_KEYS.legacyApiKey]);
  clearAllSyrveCredentials();

  return getExtensionAccessState({ refreshRemote: false });
}

async function claimExtensionKey({ requestId, claimCode }) {
  const storageData = await storageGet([STORAGE_KEYS.extensionRequestId]);
  const normalizedRequestId = String(requestId ?? storageData[STORAGE_KEYS.extensionRequestId] ?? '').trim();
  const normalizedClaimCode = String(claimCode ?? '').trim();

  if (!normalizedRequestId) {
    throw new Error('Спочатку запросіть доступ для пристрою, щоб отримати request ID.');
  }

  if (!normalizedClaimCode) {
    throw new Error('Введіть код підтвердження від адміністратора.');
  }

  let response;
  try {
    response = await fetch(EXTENSION_ACCESS_CLAIM_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        requestId: normalizedRequestId,
        claimCode: normalizedClaimCode
      })
    });
  } catch (error) {
    throw new Error('Не вдалося звернутися до сервера підтвердження доступу. Перевірте мережу та доступність сервера.');
  }

  const payload = await readJsonResponse(response);
  if (!response.ok) {
    throw new Error(buildAccessClaimErrorMessage(response.status, payload));
  }

  const extensionKey = String(payload?.extensionKey ?? '').trim();
  if (!extensionKey) {
    throw new Error('Сервер підтвердження не повернув персональний ключ доступу.');
  }

  await storageSet({
    [STORAGE_KEYS.extensionRequestId]: extractRequestId(payload) || normalizedRequestId,
    [STORAGE_KEYS.extensionKey]: extensionKey,
    [STORAGE_KEYS.extensionScopes]: extractExtensionAccessScopes(payload),
    [STORAGE_KEYS.accessNotice]: 'Персональний доступ для цього пристрою активовано.'
  });
  await storageRemove([STORAGE_KEYS.legacyApiKey]);
  clearAllSyrveCredentials();

  return getExtensionAccessState({ refreshRemote: false });
}

async function clearInvalidExtensionKey(message) {
  await storageRemove([STORAGE_KEYS.extensionKey, STORAGE_KEYS.extensionScopes, STORAGE_KEYS.bulkModeFormat, STORAGE_KEYS.accessNotice]);

  if (message) {
    await storageSet({
      [STORAGE_KEYS.accessNotice]: message
    });
  }

  clearAllSyrveCredentials();
}

async function getProtectedRouteAuthContext() {
  const storageData = await storageGet([
    STORAGE_KEYS.userId,
    STORAGE_KEYS.extensionRequestId,
    STORAGE_KEYS.extensionKey
  ]);
  const userId = normalizeUserId(storageData[STORAGE_KEYS.userId]);
  const requestId = String(storageData[STORAGE_KEYS.extensionRequestId] ?? '').trim();
  const extensionKey = String(storageData[STORAGE_KEYS.extensionKey] ?? '').trim();

  if (!extensionKey) {
    if (requestId) {
      throw new Error('Пристрій ще не активовано. Відкрийте popup розширення та введіть код підтвердження від адміністратора.');
    }

    throw new Error('Спочатку запросіть доступ для пристрою у popup розширення.');
  }

  return {
    userId,
    requestId,
    extensionKey
  };
}

async function fetchRemoteExtensionAccessState() {
  const { userId, extensionKey } = await getProtectedRouteAuthContext();

  let response;
  try {
    response = await fetch(EXTENSION_ACCESS_STATE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Extension-Key': extensionKey,
        'X-User-Id': userId
      },
      body: JSON.stringify({})
    });
  } catch (error) {
    throw new Error('Не вдалося оновити стан доступу пристрою. Перевірте мережу та доступність сервера.');
  }

  const payload = await readJsonResponse(response);

  if (!response.ok) {
    if (response.status === 403 && shouldClearInvalidExtensionAccess(payload)) {
      await clearInvalidExtensionKey('Персональний доступ цього пристрою відкликано або він більше недійсний. Попросіть адміністратора видати новий код підтвердження.');
    }

    throw new Error(extractServerMessage(payload) || `Сервер стану доступу повернув помилку зі статусом ${response.status}.`);
  }

  return payload?.access || {};
}

function normalizeDaoServiceStatusState(value) {
  const normalizedValue = String(value || '').trim().toLowerCase();
  return ['checking', 'online', 'offline'].includes(normalizedValue) ? normalizedValue : 'checking';
}

function buildDaoServiceStatus(result = {}) {
  const numericStatusCode = Number(result?.statusCode);
  return {
    state: normalizeDaoServiceStatusState(result?.state),
    checkedAt: typeof result?.checkedAt === 'string' && result.checkedAt.trim()
      ? result.checkedAt.trim()
      : new Date().toISOString(),
    statusCode: Number.isInteger(numericStatusCode) ? numericStatusCode : null,
    error: typeof result?.error === 'string' && result.error.trim() ? result.error.trim() : ''
  };
}

function buildDaoServiceStatusErrorMessage(statusCode) {
  if (!Number.isInteger(statusCode)) {
    return 'DAO backend повернув помилкову відповідь.';
  }

  return `DAO backend повернув HTTP ${statusCode}.`;
}

function isDaoServiceStatusStale(status) {
  const checkedAtValue = typeof status?.checkedAt === 'string' ? status.checkedAt.trim() : '';
  if (!checkedAtValue) {
    return true;
  }

  const checkedAtTime = new Date(checkedAtValue).getTime();
  if (!Number.isFinite(checkedAtTime)) {
    return true;
  }

  return Date.now() - checkedAtTime >= DAO_SERVICE_STATUS_STALE_MS;
}

function buildDaoServiceActionTitle(status) {
  if (status.state === 'online') {
    const statusSuffix = Number.isInteger(status.statusCode) ? ` (HTTP ${status.statusCode})` : '';
    return `DAO Tools+ • Сервіс онлайн${statusSuffix}`;
  }

  if (status.state === 'offline') {
    if (status.error) {
      return `DAO Tools+ • Сервіс офлайн • ${status.error}`;
    }

    if (Number.isInteger(status.statusCode)) {
      return `DAO Tools+ • Сервіс офлайн • HTTP ${status.statusCode}`;
    }

    return 'DAO Tools+ • Сервіс офлайн';
  }

  return 'DAO Tools+ • Перевірка сервісу';
}

function getDaoServiceIndicatorColor(state) {
  if (state === 'online') {
    return '#16a34a';
  }

  if (state === 'offline') {
    return '#dc2626';
  }

  return '';
}

async function loadActionIconBitmap(path) {
  if (!actionIconBitmapCache.has(path)) {
    actionIconBitmapCache.set(path, (async () => {
      const response = await fetch(chrome.runtime.getURL(path));
      if (!response.ok) {
        throw new Error(`Не вдалося завантажити action icon: ${path}`);
      }

      const blob = await response.blob();
      return createImageBitmap(blob);
    })());
  }

  return actionIconBitmapCache.get(path);
}

async function buildDaoServiceActionIconFrame(size, state) {
  const sourcePath = DAO_SERVICE_ACTION_ICON_SOURCE_PATHS[size] || DEFAULT_ACTION_ICON_PATHS[48];
  const sourceBitmap = await loadActionIconBitmap(sourcePath);
  const canvas = new OffscreenCanvas(size, size);
  const context = canvas.getContext('2d');

  if (!context) {
    throw new Error('Не вдалося створити контекст для action icon.');
  }

  context.clearRect(0, 0, size, size);
  context.drawImage(sourceBitmap, 0, 0, size, size);

  const indicatorColor = getDaoServiceIndicatorColor(state);
  if (!indicatorColor) {
    return context.getImageData(0, 0, size, size);
  }

  const outerRadius = size <= 16 ? 3 : size <= 32 ? 4.5 : 6;
  const innerRadius = outerRadius - (size <= 16 ? 1 : 1.25);
  const offset = size <= 16 ? 1 : size <= 32 ? 1.5 : 2;
  const centerX = size - outerRadius - offset;
  const centerY = size - outerRadius - offset;

  context.beginPath();
  context.arc(centerX, centerY, outerRadius, 0, Math.PI * 2);
  context.fillStyle = 'rgba(255, 255, 255, 0.96)';
  context.fill();

  context.beginPath();
  context.arc(centerX, centerY, innerRadius, 0, Math.PI * 2);
  context.fillStyle = indicatorColor;
  context.fill();

  return context.getImageData(0, 0, size, size);
}

async function getDaoServiceActionIconImageData(state) {
  if (!daoServiceActionIconCache.has(state)) {
    daoServiceActionIconCache.set(state, (async () => {
      const imageData = {};

      for (const size of DAO_SERVICE_ACTION_ICON_SIZES) {
        imageData[size] = await buildDaoServiceActionIconFrame(size, state);
      }

      return imageData;
    })());
  }

  return daoServiceActionIconCache.get(state);
}

async function applyDaoServiceActionBadge(status) {
  const normalizedStatus = buildDaoServiceStatus(status);
  const hasIndicator = normalizedStatus.state === 'online' || normalizedStatus.state === 'offline';

  const iconOptions = hasIndicator
    ? { imageData: await getDaoServiceActionIconImageData(normalizedStatus.state) }
    : { path: DEFAULT_ACTION_ICON_PATHS };

  await chrome.action.setTitle({
    title: buildDaoServiceActionTitle(normalizedStatus)
  });

  await chrome.action.setBadgeText({
    text: ''
  });

  await chrome.action.setIcon(iconOptions);
}

async function getStoredDaoServiceStatus() {
  const storageData = await storageGet([STORAGE_KEYS.daoServiceStatus]);
  return buildDaoServiceStatus(storageData?.[STORAGE_KEYS.daoServiceStatus]);
}

async function persistDaoServiceStatus(status) {
  const normalizedStatus = buildDaoServiceStatus(status);
  await storageSet({
    [STORAGE_KEYS.daoServiceStatus]: normalizedStatus
  });
  applyDaoServiceActionBadge(normalizedStatus);
  return normalizedStatus;
}

function ensureDaoServiceStatusAlarm() {
  chrome.alarms.create(DAO_SERVICE_STATUS_ALARM_NAME, {
    periodInMinutes: DAO_SERVICE_STATUS_ALARM_PERIOD_MINUTES
  });
}

async function getDaoServiceStatus(options = {}) {
  const { refresh = false } = options;
  const cachedStatus = await getStoredDaoServiceStatus();
  applyDaoServiceActionBadge(cachedStatus);

  if (!refresh && cachedStatus.state !== 'checking' && !isDaoServiceStatusStale(cachedStatus)) {
    return cachedStatus;
  }

  return refreshDaoServiceStatusCache();
}

async function refreshDaoServiceStatusCache() {
  const status = await fetchDaoServiceStatus();
  return persistDaoServiceStatus(status);
}

async function fetchDaoServiceStatus() {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), DAO_SERVICE_STATUS_TIMEOUT_MS);

  try {
    const response = await fetch(DAO_ACCESS_SERVER_BASE_URL, {
      method: 'GET',
      cache: 'no-store',
      signal: controller.signal
    });

    if (!response.ok) {
      return buildDaoServiceStatus({
        state: 'offline',
        statusCode: response.status,
        error: buildDaoServiceStatusErrorMessage(response.status)
      });
    }

    return buildDaoServiceStatus({
      state: 'online',
      statusCode: response.status
    });
  } catch (error) {
    return buildDaoServiceStatus({
      state: 'offline',
      error: error?.name === 'AbortError'
        ? 'Час очікування відповіді DAO backend вичерпано.'
        : 'Не вдалося звернутися до DAO backend.'
    });
  } finally {
    clearTimeout(timeoutId);
  }
}

function sanitizeLicenseCheckServer(server) {
  if (!server || typeof server !== 'object') {
    return {};
  }

  const result = {};
  const stringFields = ['companyName', 'serialNumber', 'crmId', 'serverType', 'licenseStatus'];
  stringFields.forEach((fieldName) => {
    const fieldValue = server[fieldName];
    if (typeof fieldValue === 'string' && fieldValue.trim()) {
      result[fieldName] = fieldValue.trim();
    }
  });

  if (typeof server.statusMessage === 'string' && server.statusMessage.trim()) {
    result.statusMessage = server.statusMessage.trim();
  } else if (server.statusMessage === null) {
    result.statusMessage = null;
  }

  return result;
}

function sanitizeLicenseCheckLicenses(licenses) {
  if (!Array.isArray(licenses)) {
    return [];
  }

  return licenses.reduce((result, license) => {
    if (!license || typeof license !== 'object') {
      return result;
    }

    const id = typeof license.id === 'string' || typeof license.id === 'number'
      ? String(license.id).trim()
      : '';
    const name = typeof license.name === 'string' ? license.name.trim() : '';
    const friendlyName = typeof license.friendlyName === 'string' ? license.friendlyName.trim() : '';
    const groupId = typeof license.groupId === 'string' && license.groupId.trim()
      ? license.groupId.trim()
      : 'other';
    const countValue = Number(license.count);
    const count = Number.isFinite(countValue) ? countValue : null;
    const validUntil = typeof license.validUntil === 'string' ? license.validUntil.trim() : '';

    if (!id && !name && !friendlyName) {
      return result;
    }

    result.push({
      id,
      name,
      friendlyName,
      groupId,
      count,
      validUntil
    });

    return result;
  }, []);
}

function sanitizeLicenseSnapshot(license) {
  if (!license || typeof license !== 'object') {
    return null;
  }

  const [normalizedLicense] = sanitizeLicenseSnapshots([license]);
  return normalizedLicense || null;
}

function sanitizeLicenseSnapshots(licenses) {
  if (!Array.isArray(licenses)) {
    return [];
  }

  return licenses.reduce((result, license) => {
    if (!license || typeof license !== 'object') {
      return result;
    }

    const id = typeof license.id === 'string' || typeof license.id === 'number'
      ? String(license.id).trim()
      : '';
    const name = typeof license.name === 'string' ? license.name.trim() : '';
    const friendlyName = typeof license.friendlyName === 'string' ? license.friendlyName.trim() : '';
    const groupId = typeof license.groupId === 'string' && license.groupId.trim()
      ? license.groupId.trim()
      : 'other';
    const groupTitle = typeof license.groupTitle === 'string' && license.groupTitle.trim()
      ? license.groupTitle.trim()
      : '';
    const countValue = Number(license.count);
    const count = Number.isFinite(countValue) ? countValue : null;
    const validUntil = sanitizeLicenseValidityValue(license.validUntil) || '';

    if (!id && !name && !friendlyName) {
      return result;
    }

    result.push({
      id,
      name,
      friendlyName,
      groupId,
      groupTitle,
      count,
      validUntil
    });

    return result;
  }, []);
}

function normalizeSyrveCredentialSet(payload, fallbackCredentialId) {
  const credentialIdValue = Number(payload?.credentialId ?? fallbackCredentialId);
  const credentialId = Number.isSafeInteger(credentialIdValue) && credentialIdValue > 0
    ? credentialIdValue
    : fallbackCredentialId;
  const credentials = Array.isArray(payload?.credentials)
    ? payload.credentials.reduce((result, credential, index) => {
      const login = typeof credential?.login === 'string' ? credential.login.trim() : '';
      const password = typeof credential?.password === 'string' ? credential.password : '';
      const id = typeof credential?.id === 'string' && credential.id.trim()
        ? credential.id.trim()
        : `sa-${credentialId}-${index + 1}`;

      if (!login || !password.trim()) {
        return result;
      }

      result.push({ id, login, password });
      return result;
    }, [])
    : [];

  if (!credentials.length) {
    throw new Error('Сервер credentials повернув порожній список учёток.');
  }

  return {
    credentialId,
    credentials
  };
}

async function fetchSyrveCredentials() {
  const { userId, extensionKey } = await getProtectedRouteAuthContext();
  const credentialId = normalizeCredentialId(userId);
  let response;

  try {
    response = await fetch(CREDENTIALS_LOOKUP_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Extension-Key': extensionKey,
        'X-User-Id': userId
      },
      body: JSON.stringify({ id: credentialId })
    });
  } catch (error) {
    throw new Error('Не вдалося звернутися до сервера credentials. Перевірте мережу та доступність сервера.');
  }

  const payload = await readJsonResponse(response);

  if (!response.ok) {
    if (response.status === 403 && shouldClearInvalidExtensionAccess(payload)) {
      await clearInvalidExtensionKey('Персональний доступ цього пристрою відкликано або він більше недійсний. Попросіть адміністратора видати новий код підтвердження.');
    }

    throw new Error(buildCredentialsLookupErrorMessage(response.status, payload));
  }

  return normalizeSyrveCredentialSet(payload, credentialId);
}

async function fetchCrmHandoffUrl({ syrveWebUrl }) {
  const { userId, extensionKey } = await getProtectedRouteAuthContext();
  const normalizedSyrveWebUrl = normalizeCrmHandoffSyrveWebUrl(syrveWebUrl);
  let response;

  try {
    response = await fetch(CRM_HANDOFF_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Extension-Key': extensionKey,
        'X-User-Id': userId
      },
      body: JSON.stringify({
        syrveWebUrl: normalizedSyrveWebUrl
      })
    });
  } catch (error) {
    throw new Error('Не вдалося звернутися до SLM для переходу в довідники. Перевірте мережу та доступність сервера.');
  }

  const payload = await readJsonResponse(response);

  if (!response.ok) {
    if (response.status === 403 && shouldClearInvalidExtensionAccess(payload)) {
      await clearInvalidExtensionKey('Персональний доступ цього пристрою відкликано або він більше недійсний. Попросіть адміністратора видати новий код підтвердження.');
    }

    throw new Error(buildCrmHandoffErrorMessage(response.status, payload));
  }

  return normalizeCrmHandoffConnectUrl(payload?.url);
}

function buildLicensePricingErrorMessage(status, payload) {
  const serverMessage = extractServerMessage(payload);

  switch (status) {
    case 401:
      return 'Розширення не передало X-Extension-Key для отримання прайсу. Завершіть доступ пристрою у popup.';
    case 403:
      return 'Персональний доступ цього пристрою недійсний або відкликаний. Попросіть адміністратора видати новий код підтвердження.';
    case 429:
      return 'Забагато запитів прайсу. Спробуйте за хвилину.';
    case 503:
      return 'Прайс калькулятора вимкнено в SLM.';
    default:
      return serverMessage || `SLM повернув помилку прайсу зі статусом ${status}.`;
  }
}

function sanitizeLicensePricingText(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function sanitizeLicensePricingNumber(value) {
  const numericValue = Number(value);
  return Number.isFinite(numericValue) && numericValue >= 0 ? numericValue : null;
}

const LICENSE_PRICE_CHANGE_KINDS = new Set(['uah', 'usd', 'added', 'removed', 'details']);

function sanitizeLicensePriceChanges(value) {
  const toNumberOrNull = (item) => (item === null || item === undefined ? null : sanitizeLicensePricingNumber(item));

  return (Array.isArray(value) ? value.slice(0, 60) : []).reduce((result, change) => {
    const label = sanitizeLicensePricingText(change?.label).slice(0, 200);

    if (LICENSE_PRICE_CHANGE_KINDS.has(change?.kind) && label) {
      result.push({ kind: change.kind, label, from: toNumberOrNull(change.from), to: toNumberOrNull(change.to) });
    }

    return result;
  }, []);
}

function sanitizeLicensePricing(pricing) {
  if (!pricing || typeof pricing !== 'object') {
    throw new Error('SLM повернув некоректний прайс.');
  }

  const frontPricingTable = Array.isArray(pricing.frontPricingTable)
    ? pricing.frontPricingTable.map((tier) => ({
      proMonthlyUah: sanitizeLicensePricingNumber(tier?.proMonthlyUah),
      enterpriseMonthlyUah: sanitizeLicensePricingNumber(tier?.enterpriseMonthlyUah),
      setupUsd: sanitizeLicensePricingNumber(tier?.setupUsd),
    }))
    : [];

  // Розрахунок фронтів спирається рівно на 4 тарифи.
  if (frontPricingTable.length !== 4 || frontPricingTable.some((tier) => Object.values(tier).some((value) => value === null))) {
    throw new Error('SLM повернув неповний прайс фронтів.');
  }

  const addonLicenses = (Array.isArray(pricing.addonLicenses) ? pricing.addonLicenses : []).reduce((result, addon) => {
    const id = sanitizeLicensePricingText(addon?.id);
    const originalName = sanitizeLicensePricingText(addon?.originalName);
    const monthlyUah = sanitizeLicensePricingNumber(addon?.monthlyUah);
    const setupUsd = sanitizeLicensePricingNumber(addon?.setupUsd);

    if (!id || !originalName || monthlyUah === null || setupUsd === null) {
      return result;
    }

    result.push({
      id,
      moduleId: sanitizeLicensePricingText(addon.moduleId),
      group: addon.group === 'mobile' ? 'mobile' : 'other',
      name: sanitizeLicensePricingText(addon.name),
      originalName,
      description: sanitizeLicensePricingText(addon.description),
      supplyCloud: sanitizeLicensePricingText(addon.supplyCloud),
      supplyLt: sanitizeLicensePricingText(addon.supplyLt),
      monthlyUah,
      setupUsd,
      setupIsFrom: addon.setupIsFrom === true,
      requiresEnterprise: addon.requiresEnterprise === true,
      freeInCloud: addon.freeInCloud === true,
      cloudOnly: addon.cloudOnly === true,
      note: sanitizeLicensePricingText(addon.note),
    });
    return result;
  }, []);

  const frontLicenses = (Array.isArray(pricing.frontLicenses) ? pricing.frontLicenses : []).reduce((result, item) => {
    const name = sanitizeLicensePricingText(item?.name);

    if (name) {
      result.push({
        moduleId: sanitizeLicensePricingText(item.moduleId),
        name,
        module: sanitizeLicensePricingText(item.module),
        supplyCloud: sanitizeLicensePricingText(item.supplyCloud),
        supplyLt: sanitizeLicensePricingText(item.supplyLt),
      });
    }

    return result;
  }, []);

  return {
    priceUpdatedAt: sanitizeLicensePricingText(pricing.priceUpdatedAt),
    priceChanges: sanitizeLicensePriceChanges(pricing.priceChanges),
    frontPricingTable,
    frontLicenses,
    addonLicenses,
  };
}

async function fetchLicensePricing({ refresh = false } = {}) {
  // Спершу перевіряємо доступ пристрою: без ключа кеш не віддаємо.
  const { userId, extensionKey } = await getProtectedRouteAuthContext();
  const cacheKey = `${userId}:${extensionKey.slice(0, 12)}`;

  if (
    !refresh
    && licensePricingCache
    && licensePricingCache.cacheKey === cacheKey
    && Date.now() - licensePricingCache.loadedAt < LICENSE_PRICING_CACHE_TTL_MS
  ) {
    return licensePricingCache.pricing;
  }

  let response;

  try {
    response = await fetch(LICENSE_PRICING_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Extension-Key': extensionKey,
        'X-User-Id': userId
      },
      body: JSON.stringify({})
    });
  } catch (error) {
    throw new Error('Не вдалося звернутися до SLM за прайсом. Перевірте мережу та доступність сервера.');
  }

  const payload = await readJsonResponse(response);

  if (!response.ok) {
    licensePricingCache = null;

    if (response.status === 403 && shouldClearInvalidExtensionAccess(payload)) {
      await clearInvalidExtensionKey('Персональний доступ цього пристрою відкликано або він більше недійсний. Попросіть адміністратора видати новий код підтвердження.');
    }

    throw new Error(buildLicensePricingErrorMessage(response.status, payload));
  }

  const pricing = sanitizeLicensePricing(payload?.pricing);
  licensePricingCache = { pricing, cacheKey, loadedAt: Date.now() };
  return pricing;
}

async function fetchSyrveLicenseCheck({ address, port }) {
  const { userId, extensionKey } = await getProtectedRouteAuthContext();

  const normalizedAddress = normalizeLicenseServerAddress(address);
  const normalizedPort = normalizeLicenseServerPort(port);

  let response;
  try {
    response = await fetch(LICENSE_CHECK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Extension-Key': extensionKey,
        'X-User-Id': userId
      },
      body: JSON.stringify({
        address: normalizedAddress,
        port: normalizedPort
      })
    });
  } catch (error) {
    throw new Error('Не вдалося звернутися до сервера перевірки ліцензій. Перевірте мережу та доступність сервера.');
  }

  const payload = await readJsonResponse(response);

  if (!response.ok) {
    if (response.status === 403 && shouldClearInvalidExtensionAccess(payload)) {
      await clearInvalidExtensionKey('Персональний доступ цього пристрою відкликано або він більше недійсний. Попросіть адміністратора видати новий код підтвердження.');
    }

    throw new Error(buildLicenseCheckErrorMessage(response.status, payload));
  }

  const result = payload?.result;
  if (!result || typeof result !== 'object') {
    throw new Error('Сервер license check повернув некоректну відповідь.');
  }

  return {
    address: normalizedAddress,
    port: normalizedPort,
    result: {
      server: sanitizeLicenseCheckServer(result.server),
      licenses: sanitizeLicenseCheckLicenses(result.licenses)
    }
  };
}

async function fetchServerAvailability({ address, port }) {
  const { userId, extensionKey } = await getProtectedRouteAuthContext();

  const normalizedAddress = normalizeServerAvailabilityAddress(address);
  const normalizedPort = normalizeServerAvailabilityPort(port);

  let response;
  try {
    response = await fetch(SERVER_AVAILABILITY_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Extension-Key': extensionKey,
        'X-User-Id': userId
      },
      body: JSON.stringify({
        address: normalizedAddress,
        port: normalizedPort
      })
    });
  } catch (error) {
    throw new Error('Не вдалося звернутися до сервера перевірки доступності. Перевірте мережу та доступність сервера.');
  }

  const payload = await readJsonResponse(response);

  if (!response.ok) {
    if (response.status === 403 && shouldClearInvalidExtensionAccess(payload)) {
      await clearInvalidExtensionKey('Персональний доступ цього пристрою відкликано або він більше недійсний. Попросіть адміністратора видати новий код підтвердження.');
    }

    throw new Error(buildServerAvailabilityErrorMessage(response.status, payload));
  }

  const result = payload?.result;
  if (!result || typeof result !== 'object') {
    throw new Error('Сервер перевірки доступності повернув некоректну відповідь.');
  }

  const normalizedResult = {
    reachable: result.reachable === true,
    status: Number.isInteger(result.status) ? result.status : null,
    url: typeof result.url === 'string' && result.url.trim() ? result.url.trim() : ''
  };

  if (!normalizedResult.url) {
    throw new Error('Сервер перевірки доступності повернув некоректну відповідь.');
  }

  if (typeof result.error === 'string' && result.error.trim()) {
    normalizedResult.error = result.error.trim();
  }

  return normalizedResult;
}

async function fetchSyrveLicenseUpdate({ address, port, batchId = null, serialNumber = null }) {
  const { userId, extensionKey } = await getProtectedRouteAuthContext();

  const normalizedAddress = normalizeLicenseServerAddress(address);
  const normalizedPort = normalizeLicenseServerPort(port);
  const normalizedBatchId = typeof batchId === 'string' && batchId.trim()
    ? batchId.trim().slice(0, 128)
    : null;
  const normalizedSerialNumber = typeof serialNumber === 'string' && serialNumber.trim()
    ? serialNumber.trim()
    : null;

  let response;
  try {
    response = await fetch(LICENSE_UPDATE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Extension-Key': extensionKey,
        'X-User-Id': userId
      },
      body: JSON.stringify({
        address: normalizedAddress,
        port: normalizedPort,
        batchId: normalizedBatchId,
        serialNumber: normalizedSerialNumber
      })
    });
  } catch (error) {
    throw new Error('Не вдалося звернутися до сервера оновлення ліцензій. Перевірте мережу та доступність сервера.');
  }

  const payload = await readJsonResponse(response);

  if (!response.ok) {
    if (response.status === 403) {
      if (shouldClearInvalidExtensionAccess(payload)) {
        await clearInvalidExtensionKey('Персональний доступ цього пристрою відкликано або він більше недійсний. Попросіть адміністратора видати новий код підтвердження.');
      } else {
        await removeStoredExtensionAccessScope('license.bulk');
      }
    }

    throw new Error(buildLicenseUpdateErrorMessage(response.status, payload));
  }

  return {
    address: normalizedAddress,
    port: normalizedPort,
    batchId: typeof payload?.batchId === 'string' && payload.batchId.trim() ? payload.batchId.trim() : normalizedBatchId,
    operationId: typeof payload?.operationId === 'string' && payload.operationId.trim() ? payload.operationId.trim() : '',
    resultCode: typeof payload?.resultCode === 'string' && payload.resultCode.trim() ? payload.resultCode.trim() : '',
    outcome: typeof payload?.outcome === 'string' && payload.outcome.trim() ? payload.outcome.trim() : '',
    correlationId: typeof payload?.correlationId === 'string' && payload.correlationId.trim() ? payload.correlationId.trim() : '',
    statusMessage: typeof payload?.statusMessage === 'string' && payload.statusMessage.trim() ? payload.statusMessage.trim() : '',
    verifyAttempts: Number.isFinite(Number(payload?.verifyAttempts)) ? Number(payload.verifyAttempts) : 0,
    requestedTargetLabel: typeof payload?.requestedTargetLabel === 'string' && payload.requestedTargetLabel.trim() ? payload.requestedTargetLabel.trim() : '',
    targetLicenseDisplayName: typeof payload?.targetLicenseDisplayName === 'string' && payload.targetLicenseDisplayName.trim() ? payload.targetLicenseDisplayName.trim() : '',
    updatedTargetLicenseDisplayName: typeof payload?.updatedTargetLicenseDisplayName === 'string' && payload.updatedTargetLicenseDisplayName.trim() ? payload.updatedTargetLicenseDisplayName.trim() : '',
    targetBefore: sanitizeLicenseSnapshot(payload?.targetBefore),
    targetAfter: sanitizeLicenseSnapshot(payload?.targetAfter),
    serverBefore: sanitizeLicenseCheckServer(payload?.serverBefore),
    serverAfter: sanitizeLicenseCheckServer(payload?.serverAfter),
    licensesBefore: sanitizeLicenseSnapshots(payload?.licensesBefore),
    licensesAfter: sanitizeLicenseSnapshots(payload?.licensesAfter),
    targetLicenses: sanitizeLicenseSnapshots(payload?.targetLicenses),
    targetValidUntilBefore: sanitizeLicenseValidityValue(payload?.targetValidUntilBefore),
    targetValidUntilAfter: sanitizeLicenseValidityValue(payload?.targetValidUntilAfter),
    targetAvailableBefore: payload?.targetAvailableBefore === true,
    targetAvailableAfter: payload?.targetAvailableAfter === true,
    updatedTargetLicenses: sanitizeLicenseUpdateLicenses(payload?.updatedTargetLicenses),
    diffSummary: sanitizeLicenseUpdateDiffSummary(payload?.diffSummary),
    freshnessStatus: typeof payload?.freshnessStatus === 'string' && payload.freshnessStatus.trim()
      ? payload.freshnessStatus.trim()
      : '',
    freshnessReason: typeof payload?.freshnessReason === 'string' && payload.freshnessReason.trim()
      ? payload.freshnessReason.trim()
      : '',
    freshnessThresholdDays: Number.isSafeInteger(Number(payload?.freshnessThresholdDays))
      ? Number(payload.freshnessThresholdDays)
      : null,
    nearestTargetValidUntil: sanitizeLicenseValidityValue(payload?.nearestTargetValidUntil),
    nearestTargetDaysUntilExpiry: Number.isSafeInteger(Number(payload?.nearestTargetDaysUntilExpiry))
      ? Number(payload.nearestTargetDaysUntilExpiry)
      : null,
    hasTargetDateChange: payload?.hasTargetDateChange === true,
    isCurrentByThreshold: payload?.isCurrentByThreshold === true,
  };
}

function cacheSyrveCredentialsForTab(tabId, credentialSet) {
  if (tabId === undefined) {
    return;
  }

  const credentials = Array.isArray(credentialSet?.credentials)
    ? credentialSet.credentials.map((credential) => ({
      id: credential.id,
      login: credential.login,
      password: credential.password
    }))
    : [];

  if (!credentials.length) {
    SYRVE_TAB_CREDENTIALS.delete(tabId);
    return;
  }

  SYRVE_TAB_CREDENTIALS.set(tabId, {
    credentialId: credentialSet.credentialId ?? null,
    credentials,
    currentIndex: 0,
    exhausted: false,
    expiresAt: Date.now() + SYRVE_CREDENTIAL_TTL_MS
  });
}

function getSyrveCredentialsForTab(tabId) {
  const cached = SYRVE_TAB_CREDENTIALS.get(tabId);
  if (!cached) {
    return null;
  }

  if (cached.expiresAt <= Date.now()) {
    SYRVE_TAB_CREDENTIALS.delete(tabId);
    return null;
  }

  if (cached.exhausted === true) {
    return null;
  }

  const credential = cached.credentials[cached.currentIndex];
  if (!credential) {
    return null;
  }

  return {
    credentialId: cached.credentialId,
    credential,
    attemptIndex: cached.currentIndex,
    total: cached.credentials.length
  };
}

function isSyrveCredentialsExhaustedForTab(tabId) {
  const cached = SYRVE_TAB_CREDENTIALS.get(tabId);
  if (!cached) {
    return false;
  }

  if (cached.expiresAt <= Date.now()) {
    SYRVE_TAB_CREDENTIALS.delete(tabId);
    return false;
  }

  return cached.exhausted === true;
}

function advanceSyrveCredentialsForTab(tabId) {
  const cached = SYRVE_TAB_CREDENTIALS.get(tabId);
  if (!cached) {
    return null;
  }

  if (cached.expiresAt <= Date.now()) {
    SYRVE_TAB_CREDENTIALS.delete(tabId);
    return null;
  }

  const nextIndex = cached.currentIndex + 1;
  if (nextIndex >= cached.credentials.length) {
    cached.currentIndex = cached.credentials.length;
    cached.exhausted = true;
    return null;
  }

  cached.currentIndex = nextIndex;
  cached.expiresAt = Date.now() + SYRVE_CREDENTIAL_TTL_MS;
  cached.exhausted = false;
  return getSyrveCredentialsForTab(tabId);
}

function markSyrveCredentialAttemptSuccess(tabId) {
  const cached = SYRVE_TAB_CREDENTIALS.get(tabId);
  if (!cached) {
    return;
  }

  if (cached.expiresAt <= Date.now()) {
    SYRVE_TAB_CREDENTIALS.delete(tabId);
    return;
  }

  SYRVE_TAB_CREDENTIALS.delete(tabId);
}

function buildSyrveCredentialAttemptResponse(attempt) {
  return {
    ok: true,
    credential: {
      id: attempt.credential.id,
      login: attempt.credential.login,
      password: attempt.credential.password
    },
    attempt: {
      index: attempt.attemptIndex + 1,
      total: attempt.total,
      credentialId: attempt.credentialId
    }
  };
}

function clearSyrveCredentialsForTab(tabId) {
  SYRVE_TAB_CREDENTIALS.delete(tabId);
}

function normalizeLoyaltyLogin(value) {
  const normalizedValue = String(value ?? '').trim();
  if (!normalizedValue) {
    throw new Error('Missing Loyalty login');
  }

  return normalizedValue;
}

function cacheLoyaltyCredentialsForTab(tabId, credential) {
  if (tabId === undefined) {
    return;
  }

  LOYALTY_TAB_CREDENTIALS.set(tabId, {
    login: credential.login,
    password: credential.password,
    expiresAt: Date.now() + SYRVE_CREDENTIAL_TTL_MS
  });
}

function getLoyaltyCredentialsForTab(tabId) {
  const cached = LOYALTY_TAB_CREDENTIALS.get(tabId);
  if (!cached) {
    return null;
  }

  if (cached.expiresAt <= Date.now()) {
    LOYALTY_TAB_CREDENTIALS.delete(tabId);
    return null;
  }

  return {
    login: cached.login,
    password: cached.password
  };
}

function clearLoyaltyCredentialsForTab(tabId) {
  LOYALTY_TAB_CREDENTIALS.delete(tabId);
}

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== 'toggle-pip') return;

  try {
    const targetTabId = tab?.id ?? (await getActiveTabId());
    if (targetTabId === undefined) {
      log.debug('No target tab for keyboard command', { command });
      return;
    }

    const targetTab = tab ?? await chrome.tabs.get(targetTabId);
    log.info('Keyboard command received', {
      tabId: targetTabId,
      url: targetTab?.url,
      trigger: 'command'
    });

    if (!isSupportedUrl(targetTab.url)) {
      log.debug('Command ignored — unsupported URL', { tabId: targetTabId, url: targetTab?.url });
      return;
    }

    await requestToggle(targetTabId, 'command');
  } catch (error) {
    log.error('Failed to handle toggle command', error);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.source === 'pip-page') {
    const tabId = sender.tab?.id;
    if (tabId === undefined) return false;

    log.debug('Message received from pip-page', { tabId, type: message.type });

    switch (message.type) {
      case 'PIP_STATE':
        TAB_STATE.set(tabId, message.state === 'open');
        updateBadge(tabId);
        log.info('Updated PiP state', {
          tabId,
          state: message.state,
          trigger: message.trigger
        });
        break;
      case 'PIP_UNSUPPORTED':
        TAB_STATE.delete(tabId);
        chrome.action.setBadgeText({ tabId, text: '!' });
        setTimeout(() => chrome.action.setBadgeText({ tabId, text: '' }), 2500);
        log.warn('Tab reported PiP as unsupported', {
          tabId,
          reason: message.reason,
          details: message.message
        });
        break;
      case 'PIP_RESTORE_REQUEST':
        log.info('Tab requested PiP restore', { tabId, trigger: message.trigger });
        requestToggle(tabId, 'page-request');
        break;
      default:
        log.debug('Unknown message type received', { tabId, type: message.type });
        break;
    }

    return false;
  }

  if (message?.action === 'OPEN_HEALTH_PERIOD_TAB') {
    const requesterTabId = sender.tab?.id;
    if (requesterTabId === undefined || !message.server || !message.requestId) {
      sendResponse({ ok: false, error: 'Missing requester tab, server, or request id' });
      return false;
    }

    openHealthPeriodTab({
      requesterTabId,
      server: message.server,
      port: message.port,
      requestId: message.requestId
    })
      .then((serviceTabId) => sendResponse({ ok: true, tabId: serviceTabId }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to open health tab' }));

    return true;
  }

  if (message?.action === 'OPEN_SYRVE_CONNECTIONS_SNAPSHOT') {
    const requesterTabId = sender.tab?.id;
    if (requesterTabId === undefined || !message.server || !message.requestId) {
      sendResponse({ ok: false, error: 'Missing requester tab, server, or request id' });
      return false;
    }

    openConnectionsSnapshotTab({
      requesterTabId,
      server: message.server,
      port: message.port,
      requestId: message.requestId,
      connectionsHelpDeskPayload: message.connectionsHelpDeskPayload
    })
      .then((serviceTabId) => sendResponse({ ok: true, tabId: serviceTabId }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to read Syrve connections' }));

    return true;
  }

  if (message?.action === 'RUN_SYRVE_CONNECTIONS_STALE_ACTION') {
    const requesterTabId = sender.tab?.id;
    if (requesterTabId === undefined || !message.requestId) {
      sendResponse({ ok: false, error: 'Missing requester tab or request id' });
      return false;
    }

    runConnectionsSnapshotStaleAction(requesterTabId, message.requestId)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to run stale license action' }));

    return true;
  }

  if (message?.action === 'CANCEL_SYRVE_CONNECTIONS_SNAPSHOT') {
    const requesterTabId = sender.tab?.id;
    if (requesterTabId === undefined || !message.requestId) {
      sendResponse({ ok: false, error: 'Missing requester tab or request id' });
      return false;
    }

    cancelConnectionsSnapshotRequest(requesterTabId, message.requestId)
      .then((cancelled) => sendResponse({ ok: true, cancelled }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to cancel Syrve connections request' }));

    return true;
  }

  if (message?.action === 'OPEN_SYRVE_PAGE') {
    if (!message.server || !message.path) {
      sendResponse({ ok: false, error: 'Missing server or path' });
      return false;
    }

    openSyrvePage({
      server: message.server,
      port: message.port,
      path: message.path,
      active: message.active !== false,
      connectionsHelpDeskPayload: message.connectionsHelpDeskPayload
    })
      .then((tabId) => sendResponse({ ok: true, tabId }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to open Syrve page' }));

    return true;
  }

  if (message?.action === 'GET_CONNECTIONS_HELPDESK_CONTEXT') {
    const tabId = sender.tab?.id;
    if (tabId === undefined) {
      sendResponse({ ok: false, error: 'Missing requester tab' });
      return false;
    }

    getConnectionsHelpDeskContext(tabId)
      .then((context) => sendResponse({ ok: true, available: Boolean(context?.payload) }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to read connections context' }));

    return true;
  }

  if (message?.action === 'GET_GROOVY_LICENSE_RESET_REQUEST') {
    const groovyTabId = sender.tab?.id;
    const token = normalizeGroovyLicenseResetToken(message.token);
    if (groovyTabId === undefined || !token) {
      sendResponse({ ok: false, error: 'Missing Groovy tab or reset token' });
      return false;
    }

    getGroovyLicenseResetRequest(token)
      .then((request) => {
        if (!request) {
          sendResponse({ ok: false, error: 'Запит скидання Groovy не знайдено або час його дії сплив.' });
          return;
        }

        if (request.groovyTabId !== groovyTabId || !isSameGroovyResetPage(message.pageUrl || sender.tab?.url, request.groovyUrl)) {
          sendResponse({ ok: false, error: 'Сторінка Groovy не відповідає запиту скидання.' });
          return;
        }

        sendResponse({
          ok: true,
          scriptText: request.scriptText,
          moduleCodes: request.moduleCodes
        });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to read Groovy reset request' }));

    return true;
  }

  if (message?.action === 'COMPLETE_GROOVY_LICENSE_RESET_REQUEST') {
    const groovyTabId = sender.tab?.id;
    const token = normalizeGroovyLicenseResetToken(message.token);
    if (groovyTabId === undefined || !token) {
      sendResponse({ ok: false, error: 'Missing Groovy tab or reset token' });
      return false;
    }

    getGroovyLicenseResetRequest(token)
      .then((request) => {
        if (!request) {
          sendResponse({ ok: false, error: 'Запит скидання Groovy не знайдено або час його дії сплив.' });
          return;
        }

        if (request.groovyTabId !== groovyTabId || !isSameGroovyResetPage(message.pageUrl || sender.tab?.url, request.groovyUrl)) {
          sendResponse({ ok: false, error: 'Сторінка Groovy не відповідає запиту скидання.' });
          return;
        }

        const wasCompleted = completeGroovyLicenseReset(token, {
          ok: message.ok === true,
          error: message.error,
          submitted: message.submitted
        });
        if (!wasCompleted) {
          sendResponse({ ok: false, error: 'Запит скидання Groovy вже не активний.' });
          return;
        }

        sendResponse({ ok: true });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to complete Groovy reset request' }));

    return true;
  }

  if (message?.action === 'RESET_STALE_LICENSE_CONNECTIONS') {
    const requesterTabId = sender.tab?.id;
    if (requesterTabId === undefined) {
      sendResponse({ ok: false, error: 'Missing requester tab' });
      return false;
    }

    (async () => {
      const staleLicenses = sanitizeStaleLicenseEntries(message.staleLicenses);
      if (!staleLicenses.length) {
        throw new Error('Не знайдено підсвічених завислих ліцензій.');
      }

      const moduleCodes = normalizeReleaseModuleCodes(message.moduleCodes, staleLicenses);
      if (!moduleCodes.length) {
        throw new Error('Не вдалося визначити модуль ліцензії для скидання.');
      }

      return resetStaleLicenseConnections({
        requesterTabId,
        sourceConnectionsUrl: message.sourceConnectionsUrl || sender.tab?.url,
        moduleCodes
      });
    })()
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to reset stale licenses' }));

    return true;
  }

  if (message?.action === 'CREATE_STALE_LICENSE_HELPDESK_DRAFT') {
    const requesterTabId = sender.tab?.id;
    if (requesterTabId === undefined) {
      sendResponse({ ok: false, error: 'Missing requester tab' });
      return false;
    }

    (async () => {
      const context = await getConnectionsHelpDeskContext(requesterTabId);
      const staleLicenses = sanitizeStaleLicenseEntries(message.staleLicenses);
      if (!staleLicenses.length) {
        throw new Error('Не знайдено підсвічених завислих ліцензій.');
      }

      const route = await resolveConnectionsCaptureRoute({
        requesterTabId,
        context,
        fallbackUrl: message.sourceConnectionsUrl || sender.tab?.url,
        forceHelpDesk: message.forceHelpDesk === true
      });

      if (route.mode === 'helpdesk') {
        if (!context?.payload) {
          throw new Error('Контекст Planfix для створення заявки не знайдено. Відкрийте цю сторінку кнопкою Зайняті ліцензії зі сторінки задачі Planfix.');
        }

        const activeDraftRequest = await getHelpDeskDraftRequestByRequesterTabId(requesterTabId);
        if (activeDraftRequest) {
          throw new Error('Чернетка HelpDeskEddy вже створюється або заповнюється для цієї вкладки.');
        }
      }

      return startStaleLicenseHelpDeskCapture({
        requesterTabId,
        basePayload: context?.payload || {},
        connectionsContext: context || null,
        forceHelpDesk: message.forceHelpDesk === true,
        staleLicenses,
        sourceConnectionsUrl: route.sourceConnectionsUrl
      });
    })()
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to start stale license HelpDesk flow' }));

    return true;
  }

  if (message?.action === 'PREPARE_STALE_LICENSE_SCREENSHOT_CAPTURE') {
    if (!message.requestId) {
      sendResponse({ ok: false, error: 'Missing screenshot request id' });
      return false;
    }

    (async () => {
      const request = await getStaleLicenseHelpDeskRequest(message.requestId);
      if (!request) {
        throw new Error('Запит створення скріншота не знайдено або час його дії сплив.');
      }

      await focusTabForScreenshot(request.requesterTabId);
      await waitForConnectionsCaptureReady(request.requesterTabId);
    })()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to prepare screenshot target' }));

    return true;
  }

  if (message?.action === 'STALE_LICENSE_SCREENSHOT_CAPTURE_RESULT') {
    if (!message.requestId) {
      sendResponse({ ok: false, error: 'Missing screenshot request id' });
      return false;
    }

    completeStaleLicenseHelpDeskCapture({
      requestId: message.requestId,
      ok: message.ok !== false,
      error: message.error,
      dataUrl: message.dataUrl,
      width: message.width,
      height: message.height,
      mimeType: message.mimeType,
      sourceTabId: sender.tab?.id
    })
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to complete screenshot capture' }));

    return true;
  }

  if (message?.action === 'GET_HELPDESK_DRAFT_ATTACHMENT') {
    const storageKey = normalizeAttachmentStorageKey(message.storageKey);
    if (!storageKey) {
      sendResponse({ ok: false, error: 'Missing HelpDesk attachment key' });
      return false;
    }

    sessionStorageGet(storageKey)
      .then((result) => {
        const attachment = result?.[storageKey];
        if (!attachment?.dataUrl) {
          sendResponse({ ok: false, error: 'Скріншот для заявки не знайдено або час його дії сплив.' });
          return;
        }

        sendResponse({ ok: true, attachment });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to read HelpDesk attachment' }));

    return true;
  }

  if (message?.action === 'OPEN_LOYALTY_PAGE') {
    if (!message.login) {
      sendResponse({ ok: false, error: 'Missing Loyalty login' });
      return false;
    }

    openLoyaltyPage({
      login: message.login,
      active: message.active !== false
    })
      .then((tabId) => sendResponse({ ok: true, tabId }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to open Loyalty page' }));

    return true;
  }

  if (message?.action === 'OPEN_HELPDESK_DRAFT') {
    const requesterTabId = sender.tab?.id;
    if (requesterTabId === undefined || !message.payload || typeof message.payload !== 'object') {
      sendResponse({ ok: false, error: 'Missing requester tab or payload' });
      return false;
    }

    openHelpDeskDraftTab({
      requesterTabId,
      payload: message.payload,
      active: message.active !== false
    })
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to open HelpDeskEddy draft tab' }));

    return true;
  }

  if (message?.action === 'GET_HELPDESK_DRAFT_PAYLOAD') {
    const targetTabId = sender.tab?.id;
    if (!message.requestId && targetTabId === undefined) {
      sendResponse({ ok: false, error: 'Missing HelpDeskEddy draft request id' });
      return false;
    }

    (async () => {
      let request = null;
      if (message.requestId) {
        request = await getHelpDeskDraftRequest(message.requestId);
      }

      if (!request) {
        request = await getHelpDeskDraftRequestByTabId(targetTabId);
      }

      return request;
    })()
      .then((request) => {
        if (!request?.payload) {
          sendResponse({ ok: false, error: 'Чернетку HelpDeskEddy не знайдено або час її дії сплив.' });
          return;
        }

        sendResponse({
          ok: true,
          requestId: request.requestId,
          payload: request.payload,
          requesterTabId: request.requesterTabId,
          targetTabId: request.targetTabId
        });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to read HelpDeskEddy draft payload' }));

    return true;
  }

  if (message?.action === 'COMPLETE_HELPDESK_DRAFT_REQUEST') {
    if (!message.requestId) {
      sendResponse({ ok: false, error: 'Missing HelpDeskEddy draft request id' });
      return false;
    }

    finalizeHelpDeskDraftRequest({
      requestId: message.requestId,
      ok: message.ok !== false,
      error: message.error,
      sourceTabId: sender.tab?.id
    })
      .then((found) => sendResponse({ ok: true, found }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to finalize HelpDeskEddy draft request' }));

    return true;
  }

  if (message?.action === 'GET_EXTENSION_ACCESS_STATE') {
    getExtensionAccessState()
      .then((state) => sendResponse({ ok: true, state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to read extension access state' }));

    return true;
  }

  if (message?.action === 'GET_DAO_SERVICE_STATUS') {
    getDaoServiceStatus({ refresh: message.refresh === true })
      .then((status) => sendResponse({ ok: true, status }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to read DAO service status' }));

    return true;
  }

  if (message?.action === 'SAVE_EXTENSION_USER_ID') {
    saveUserId(message.userId)
      .then((state) => sendResponse({ ok: true, state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to save user id' }));

    return true;
  }

  if (message?.action === 'REQUEST_EXTENSION_ACCESS') {
    requestExtensionAccess(message.userId)
      .then((state) => sendResponse({ ok: true, state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to request extension access' }));

    return true;
  }

  if (message?.action === 'CLAIM_EXTENSION_ACCESS') {
    claimExtensionKey({
      requestId: message.requestId,
      claimCode: message.claimCode
    })
      .then((state) => sendResponse({ ok: true, state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to claim extension access' }));

    return true;
  }

  if (message?.action === 'GET_SYRVE_CREDENTIALS') {
    const tabId = sender.tab?.id;
    if (tabId === undefined) {
      sendResponse({ ok: false, error: 'Missing tab id' });
      return false;
    }

    const credentialAttempt = getSyrveCredentialsForTab(tabId);
    if (!credentialAttempt) {
      if (isSyrveCredentialsExhaustedForTab(tabId)) {
        sendResponse({ ok: false, exhausted: true, error: 'Усі учётки для цієї вкладки вже вичерпані.' });
        return false;
      }

      if (message.requirePrepared === true) {
        sendResponse({ ok: false, error: 'Credentials для цієї вкладки не підготовлені.' });
        return false;
      }

      fetchSyrveCredentials()
        .then((credentialSet) => {
          cacheSyrveCredentialsForTab(tabId, credentialSet);
          const nextAttempt = getSyrveCredentialsForTab(tabId);
          if (!nextAttempt) {
            throw new Error('Credentials для цієї вкладки не вдалося підготувати.');
          }

          sendResponse(buildSyrveCredentialAttemptResponse(nextAttempt));
        })
        .catch((error) => {
          sendResponse({
            ok: false,
            error: error?.message || 'Credentials для цієї вкладки не знайдено або час очікування сплив.'
          });
        });
      return true;
    }

    sendResponse(buildSyrveCredentialAttemptResponse(credentialAttempt));
    return false;
  }

  if (message?.action === 'REPORT_SYRVE_LOGIN_RESULT') {
    const tabId = sender.tab?.id;
    if (tabId === undefined) {
      sendResponse({ ok: false, error: 'Missing tab id' });
      return false;
    }

    if (message.success === true) {
      markSyrveCredentialAttemptSuccess(tabId);
      sendResponse({ ok: true });
      return false;
    }

    const nextAttempt = advanceSyrveCredentialsForTab(tabId);
    if (!nextAttempt) {
      if (CONNECTIONS_SNAPSHOT_REQUESTS.has(tabId)) {
        finalizeConnectionsSnapshotRequest(tabId, {
          error: 'Усі доступні облікові записи Syrve відхилено цим сервером.'
        });
      }
      sendResponse({
        ok: false,
        exhausted: true,
        error: 'Усі доступні учётки для Syrve вичерпані.'
      });
      return false;
    }

    sendResponse(buildSyrveCredentialAttemptResponse(nextAttempt));
    return false;
  }

  if (message?.action === 'GET_LOYALTY_CREDENTIALS') {
    const tabId = sender.tab?.id;
    if (tabId === undefined) {
      sendResponse({ ok: false, error: 'Missing tab id' });
      return false;
    }

    const credentials = getLoyaltyCredentialsForTab(tabId);
    if (!credentials) {
      sendResponse({ ok: false, error: 'Credentials для Loyalty для цієї вкладки не знайдено або час очікування сплив.' });
      return false;
    }

    sendResponse({ ok: true, credential: credentials });
    return false;
  }

  if (message?.action === 'CHECK_SYRVE_LICENSE') {
    if (!message.address || message.port === undefined || message.port === null || message.port === '') {
      sendResponse({ ok: false, error: 'Missing address or port' });
      return false;
    }

    fetchSyrveLicenseCheck({
      address: message.address,
      port: message.port
    })
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to check Syrve license' }));

    return true;
  }

  if (message?.action === 'GET_LICENSE_PRICING') {
    fetchLicensePricing({ refresh: message.refresh === true })
      .then((pricing) => sendResponse({ ok: true, pricing }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to load license pricing' }));

    return true;
  }

  if (message?.action === 'OPEN_LICENSE_CALCULATOR') {
    openLicenseCalculatorTab({
      server: message.server,
      port: message.port,
      result: message.result,
      chain: message.chain,
      theme: message.theme,
      windowId: sender.tab?.windowId
    })
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to open license calculator' }));

    return true;
  }

  if (message?.action === 'UPDATE_SYRVE_LICENSE') {
    if (!message.address || message.port === undefined || message.port === null || message.port === '') {
      sendResponse({ ok: false, error: 'Missing address or port' });
      return false;
    }

    fetchSyrveLicenseUpdate({
      address: message.address,
      port: message.port,
      batchId: message.batchId,
      serialNumber: message.serialNumber
    })
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to update Syrve license' }));

    return true;
  }

  if (message?.action === 'PROBE_SERVER_AVAILABILITY') {
    if (!message.server || message.port === undefined || message.port === null || message.port === '') {
      sendResponse({ ok: false, error: 'Missing server or port' });
      return false;
    }

    fetchServerAvailability({
      address: message.server,
      port: message.port
    })
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to probe server availability' }));

    return true;
  }

  if (message?.action === 'OPEN_CRM_HANDOFF') {
    if (!message.syrveWebUrl) {
      sendResponse({ ok: false, error: 'Missing Syrve Web URL' });
      return false;
    }

    openCrmHandoff({
      syrveWebUrl: message.syrveWebUrl,
      active: message.active !== false
    })
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to open CRM handoff URL' }));

    return true;
  }

  if (message?.action === 'OPEN_CARD_WEB_URL_WITH_AUTOLOGIN') {
    if (!message.url) {
      sendResponse({ ok: false, error: 'Missing target URL' });
      return false;
    }

    openCardWebUrlWithSyrveCredentials({
      url: message.url,
      active: message.active !== false
    })
      .then((tabId) => sendResponse({ ok: true, tabId }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Failed to open card web URL' }));

    return true;
  }

  if (message?.action === 'SYRVE_HEALTH_PERIOD_RESULT') {
    const serviceTabId = sender.tab?.id;
    if (serviceTabId === undefined) return false;

    finalizeHealthPeriodRequest(serviceTabId, {
      period: message.period,
      periodStartDate: message.periodStartDate,
      version: message.version,
      versionRaw: message.versionRaw,
      error: message.error
    });
  }

  if (message?.action === 'SYRVE_CONNECTIONS_SNAPSHOT_RESULT') {
    const serviceTabId = sender.tab?.id;
    if (serviceTabId === undefined) {
      sendResponse({ ok: false, error: 'Missing service tab id' });
      return false;
    }

    if (!CONNECTIONS_SNAPSHOT_REQUESTS.has(serviceTabId)) {
      sendResponse({ ok: false, error: 'Connections snapshot request is no longer active' });
      return false;
    }

    forwardConnectionsSnapshotResult(serviceTabId, {
      snapshot: message.snapshot,
      error: message.error
    });
    sendResponse({ ok: true });
    return false;
  }

  if (message?.action === 'SYRVE_CONNECTIONS_STALE_ACTION_STATE') {
    const serviceTabId = sender.tab?.id;
    const request = serviceTabId === undefined ? null : CONNECTIONS_SNAPSHOT_REQUESTS.get(serviceTabId);
    if (!request) {
      sendResponse({ ok: false, error: 'Connections snapshot request is no longer active' });
      return false;
    }

    notifyConnectionsStaleActionState(request.requesterTabId, {
      requestId: request.requestId,
      actionState: message.actionState
    });
    sendResponse({ ok: true });
    return false;
  }

  return false;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (TAB_STATE.delete(tabId)) {
    log.debug('Cleared PiP state for closed tab', { tabId });
  }

  clearSyrveCredentialsForTab(tabId);
  clearLoyaltyCredentialsForTab(tabId);
  removeConnectionsHelpDeskContext(tabId).catch((error) => {
    log.warn('Failed to remove connections HelpDesk context', {
      tabId,
      error: error?.message
    });
  });
  removeStaleLicenseHelpDeskRequestsByTabId(tabId).catch((error) => {
    log.warn('Failed to remove stale license HelpDesk request', {
      tabId,
      error: error?.message
    });
  });

  const request = HEALTH_PERIOD_REQUESTS.get(tabId);
  if (request) {
    HEALTH_PERIOD_REQUESTS.delete(tabId);
    clearTimeout(request.timeoutId);
    notifyHealthPeriodResult(request.requesterTabId, {
      requestId: request.requestId,
      error: 'Службова вкладка отримання періоду була закрита раніше завершення.'
    });
  }

  const connectionsRequest = CONNECTIONS_SNAPSHOT_REQUESTS.get(tabId);
  if (connectionsRequest) {
    CONNECTIONS_SNAPSHOT_REQUESTS.delete(tabId);
    clearTimeout(connectionsRequest.timeoutId);
    notifyConnectionsSnapshotResult(connectionsRequest.requesterTabId, {
      requestId: connectionsRequest.requestId,
      error: 'Службову вкладку отримання зайнятих ліцензій було закрито раніше завершення.'
    });
  }

  cancelConnectionsSnapshotRequestsByRequesterTabId(tabId).catch((error) => {
    log.warn('Failed to close orphaned Syrve connections tabs', {
      requesterTabId: tabId,
      error: error?.message
    });
  });

  resolveClosedHelpDeskDraftTab(tabId).catch((error) => {
    log.warn('Failed to resolve closed HelpDeskEddy draft tab', {
      tabId,
      error: error?.message
    });
  });
});

chrome.tabs.onActivated.addListener(({ tabId }) => {
  log.debug('Tab activated, refreshing badge', { tabId });
  updateBadge(tabId);
});

async function getActiveTabId() {
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return activeTab?.id;
}

function updateBadge(tabId) {
  const isOpen = TAB_STATE.get(tabId) === true;
  chrome.action.setBadgeText({ tabId, text: isOpen ? 'ON' : '' });
  log.debug('Badge updated', { tabId, status: isOpen ? 'ON' : 'OFF' });
}

function isHttpOnlySyrveHost(server) {
  const normalizedServer = String(server ?? '').trim().toLowerCase();
  return isPublicIpv4SyrveHost(normalizedServer) || normalizedServer.endsWith('.daocloud.fun');
}

function getIpv4Octets(value) {
  const normalizedValue = String(value ?? '').trim();
  if (!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(normalizedValue)) {
    return null;
  }

  const octets = normalizedValue.split('.').map((part) => Number(part));
  return octets.every((part) => Number.isInteger(part) && part >= 0 && part <= 255) ? octets : null;
}

function isPrivateOrReservedIpv4Host(value) {
  const octets = getIpv4Octets(value);
  if (!octets) {
    return false;
  }

  const [first, second] = octets;

  if (first === 0 || first === 10 || first === 127 || first >= 224) {
    return true;
  }

  if (first === 169 && second === 254) {
    return true;
  }

  if (first === 172 && second >= 16 && second <= 31) {
    return true;
  }

  if (first === 192 && second === 168) {
    return true;
  }

  if (first === 100 && second >= 64 && second <= 127) {
    return true;
  }

  if (first === 198 && (second === 18 || second === 19)) {
    return true;
  }

  return false;
}

function isPublicIpv4SyrveHost(value) {
  return Boolean(getIpv4Octets(value)) && !isPrivateOrReservedIpv4Host(value);
}

function buildSyrvePageUrl({ server, port, path }) {
  const normalizedServer = String(server ?? '').trim().toLowerCase();
  const normalizedPort = String(port ?? '').trim();
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const protocol = isHttpOnlySyrveHost(normalizedServer) ? 'http' : 'https';
  const portSegment = normalizedPort ? `:${normalizedPort}` : '';
  return `${protocol}://${normalizedServer}${portSegment}${normalizedPath}`;
}

async function startStaleLicenseHelpDeskCapture({ requesterTabId, basePayload, connectionsContext, forceHelpDesk = false, staleLicenses, sourceConnectionsUrl }) {
  const existingRequest = await getStaleLicenseHelpDeskRequestByRequesterTabId(requesterTabId);
  if (existingRequest) {
    return {
      requestId: existingRequest.requestId,
      captureTabId: existingRequest.captureTabId || null
    };
  }

  const requestId = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  const request = {
    createdAt: Date.now(),
    requesterTabId,
    captureTabId: null,
    basePayload,
    connectionsContext,
    forceHelpDesk: forceHelpDesk === true,
    staleLicenses,
    sourceConnectionsUrl
  };
  await setStaleLicenseHelpDeskRequest(requestId, request);

  try {
    const captureTab = await createDesktopCaptureTab(requestId, requesterTabId);

    return {
      requestId,
      captureTabId: captureTab.id
    };
  } catch (error) {
    await removeStaleLicenseHelpDeskRequest(requestId);
    throw error;
  }
}

async function focusTabForScreenshot(tabId) {
  if (tabId === undefined) {
    throw new Error('Не знайдено вкладку таблиці для скріншота.');
  }

  const tab = await chrome.tabs.get(tabId);
  if (tab.windowId !== undefined) {
    await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
  }

  await chrome.tabs.update(tabId, { active: true });
}

const waitForDelay = (timeoutMs) => new Promise((resolve) => {
  setTimeout(resolve, timeoutMs);
});

async function waitForConnectionsCaptureReady(tabId, timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs;
  let lastError = null;

  while (Date.now() < deadline) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, {
        action: 'WAIT_STALE_LICENSE_CAPTURE_READY',
        timeoutMs: Math.min(1200, Math.max(250, deadline - Date.now()))
      });

      if (response?.ok) {
        return true;
      }

      lastError = new Error(response?.error || 'Таблиця ще не готова до скріншота.');
    } catch (error) {
      lastError = error;
    }

    await waitForDelay(200);
  }

  throw lastError || new Error('Не вдалося дочекатися таблиці для скріншота.');
}

function buildDesktopCapturePageUrl(requestId) {
  const url = new URL(chrome.runtime.getURL(DESKTOP_CAPTURE_PAGE_PATH));
  url.hash = new URLSearchParams({ requestId }).toString();
  return url.toString();
}

function waitForTabLoad(tabId, timeoutMs = 5000, timeoutMessage = 'Вкладка не завантажилась вчасно.') {
  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(handleUpdated);
      reject(new Error(timeoutMessage));
    }, timeoutMs);

    const finish = () => {
      clearTimeout(timeoutId);
      chrome.tabs.onUpdated.removeListener(handleUpdated);
      resolve();
    };

    const handleUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === 'complete') {
        finish();
      }
    };

    chrome.tabs.onUpdated.addListener(handleUpdated);
    chrome.tabs.get(tabId)
      .then((tab) => {
        if (tab.status === 'complete') {
          finish();
        }
      })
      .catch((error) => {
        clearTimeout(timeoutId);
        chrome.tabs.onUpdated.removeListener(handleUpdated);
        reject(error);
      });
  });
}

async function resetStaleLicenseConnections({ requesterTabId, sourceConnectionsUrl, moduleCodes }) {
  const connectionsUrl = assertConnectionsUrlAllowsGroovyReset(sourceConnectionsUrl);
  const normalizedModuleCodes = normalizeReleaseModuleCodes(moduleCodes);
  const groovyReleaseModuleCodes = expandReleaseModuleCodesForGroovy(normalizedModuleCodes);
  const scriptText = buildGroovyLicenseResetScript(normalizedModuleCodes);
  const groovyUrl = buildGroovyMaintenanceUrlFromConnectionsUrl(connectionsUrl);
  const token = createGroovyLicenseResetToken();
  const groovyResetUrl = buildGroovyLicenseResetUrl(groovyUrl, token);
  const requesterTab = await chrome.tabs.get(requesterTabId).catch(() => null);
  const createProperties = {
    url: 'about:blank',
    active: true
  };

  if (requesterTab?.windowId !== undefined) {
    createProperties.windowId = requesterTab.windowId;
  }

  const groovyTab = await chrome.tabs.create(createProperties);
  if (groovyTab.id === undefined) {
    throw new Error('Службову вкладку Groovy створено без id.');
  }

  try {
    await setGroovyLicenseResetRequest(token, {
      requesterTabId,
      groovyTabId: groovyTab.id,
      groovyUrl: groovyUrl.toString(),
      scriptText,
      moduleCodes: normalizedModuleCodes,
      groovyReleaseModuleCodes
    });

    const completionPromise = waitForGroovyLicenseResetCompletion(token);
    try {
      await chrome.tabs.update(groovyTab.id, { url: groovyResetUrl.toString() });
    } catch (navigationError) {
      const completion = GROOVY_LICENSE_RESET_COMPLETIONS.get(token);
      if (completion) {
        completion.reject(navigationError);
      }

      await completionPromise.catch(() => {});
      throw navigationError;
    }

    const completion = await completionPromise;
    if (!completion?.ok) {
      throw new Error(completion?.error || 'Не вдалося виконати Groovy-скрипт.');
    }

    await waitForDelay(GROOVY_LICENSE_RESET_AFTER_SUBMIT_DELAY_MS);
    const tabAfterSubmit = await chrome.tabs.get(groovyTab.id).catch(() => null);
    if (tabAfterSubmit?.status === 'loading') {
      await waitForTabLoad(
        groovyTab.id,
        GROOVY_LICENSE_RESET_LOAD_TIMEOUT_MS,
        'Сторінка Groovy не завершила виконання вчасно.'
      );
    }

    log.info('Executed stale license Groovy reset', {
      requesterTabId,
      groovyTabId: groovyTab.id,
      origin: groovyUrl.origin,
      moduleCodes: normalizedModuleCodes,
      groovyReleaseModuleCodes,
      submitted: completion.submitted || 'unknown'
    });

    return {
      moduleCodes: normalizedModuleCodes,
      groovyUrl: groovyUrl.toString()
    };
  } finally {
    await removeGroovyLicenseResetRequest(token).catch(() => {});
    const completion = GROOVY_LICENSE_RESET_COMPLETIONS.get(token);
    if (completion) {
      completion.reject(new Error('Запит скидання Groovy скасовано.'));
    }
    chrome.tabs.remove(groovyTab.id).catch(() => {});
    await focusTabForScreenshot(requesterTabId).catch(() => {});
  }
}

async function createDesktopCaptureTab(requestId, requesterTabId) {
  const requesterTab = await chrome.tabs.get(requesterTabId).catch(() => null);
  const createProperties = {
    url: buildDesktopCapturePageUrl(requestId),
    active: true
  };

  if (requesterTab?.windowId !== undefined) {
    createProperties.windowId = requesterTab.windowId;
  }

  const captureTab = await chrome.tabs.create(createProperties);
  if (captureTab.id === undefined) {
    throw new Error('Технічну вкладку скріншота створено без id.');
  }

  const existingRequest = await getStaleLicenseHelpDeskRequest(requestId);
  if (existingRequest) {
    await setStaleLicenseHelpDeskRequest(requestId, {
      ...existingRequest,
      captureTabId: captureTab.id
    });
  }

  await waitForTabLoad(captureTab.id);
  return captureTab;
}

async function completeStaleLicenseHelpDeskCapture({ requestId, ok, error, dataUrl, width, height, mimeType, sourceTabId }) {
  const request = await getStaleLicenseHelpDeskRequest(requestId);
  if (!request) {
    throw new Error('Запит створення заявки не знайдено або час його дії сплив.');
  }

  await removeStaleLicenseHelpDeskRequest(requestId);

  if (request.captureTabId !== undefined && request.captureTabId !== null) {
    chrome.tabs.remove(request.captureTabId).catch(() => {});
  } else if (sourceTabId !== undefined) {
    chrome.tabs.remove(sourceTabId).catch(() => {});
  }

  if (ok === false) {
    notifyStaleLicenseHelpDeskResult(request.requesterTabId, {
      requestId,
      ok: false,
      error: error || 'Скріншот не створено.'
    });
    return;
  }

  const normalizedDataUrl = String(dataUrl || '').trim();
  if (!normalizedDataUrl.startsWith('data:image/')) {
    notifyStaleLicenseHelpDeskResult(request.requesterTabId, {
      requestId,
      ok: false,
      error: 'Скріншот має некоректний формат.'
    });
    return;
  }

  let route;
  try {
    route = await resolveConnectionsCaptureRoute({
      requesterTabId: request.requesterTabId,
      context: request.connectionsContext || { payload: request.basePayload || {} },
      fallbackUrl: request.sourceConnectionsUrl || '',
      forceHelpDesk: request.forceHelpDesk === true
    });
  } catch (validationError) {
    notifyStaleLicenseHelpDeskResult(request.requesterTabId, {
      requestId,
      ok: false,
      error: validationError?.message || 'Поточна сторінка зайнятих ліцензій не відповідає контексту Planfix.'
    });
    return;
  }

  const attachmentId = `${requestId}-screenshot`;
  const fileName = createScreenshotFileName();
  const normalizedMimeType = String(mimeType || '').trim() || 'image/jpeg';
  const screenshot = {
    id: attachmentId,
    dataUrl: normalizedDataUrl,
    fileName,
    mimeType: normalizedMimeType,
    width: Number(width) || 0,
    height: Number(height) || 0
  };

  if (route.mode !== 'helpdesk') {
    const reportPayload = buildStaleLicenseReportPayload({
      basePayload: request.basePayload || {},
      sourceConnectionsUrl: route.sourceConnectionsUrl,
      staleLicenses: request.staleLicenses || [],
      screenshot
    });

    try {
      const reportResult = await openStaleLicenseReportTab({
        requesterTabId: request.requesterTabId,
        payload: reportPayload,
        active: true
      });

      notifyStaleLicenseHelpDeskResult(request.requesterTabId, {
        requestId,
        ok: true,
        flow: 'report',
        reportId: reportResult.reportId,
        reportTabId: reportResult.tabId
      });
    } catch (openError) {
      notifyStaleLicenseHelpDeskResult(request.requesterTabId, {
        requestId,
        ok: false,
        error: openError?.message || 'Не вдалося відкрити повідомлення зі скріншотом.'
      });
    }
    return;
  }

  const storageKey = `${HELPDESK_ATTACHMENT_SESSION_KEY_PREFIX}${attachmentId}`;
  await sessionStorageSet({
    [storageKey]: {
      createdAt: Date.now(),
      dataUrl: screenshot.dataUrl,
      fileName,
      mimeType: normalizedMimeType,
      insertMode: 'inline',
      displayWidth: HELPDESK_INLINE_SCREENSHOT_DISPLAY_WIDTH,
      displayHeight: HELPDESK_INLINE_SCREENSHOT_DISPLAY_HEIGHT,
      width: screenshot.width,
      height: screenshot.height
    }
  });

  const payload = buildStaleLicenseHelpDeskPayload({
    basePayload: request.basePayload || {},
    sourceConnectionsUrl: route.sourceConnectionsUrl,
    staleLicenses: request.staleLicenses || [],
    attachment: {
      id: attachmentId,
      storageKey,
      fileName,
      mimeType: normalizedMimeType,
      insertMode: 'inline',
      displayWidth: HELPDESK_INLINE_SCREENSHOT_DISPLAY_WIDTH,
      displayHeight: HELPDESK_INLINE_SCREENSHOT_DISPLAY_HEIGHT,
      width: screenshot.width,
      height: screenshot.height
    }
  });

  try {
    const draftResult = await openHelpDeskDraftTab({
      requesterTabId: request.requesterTabId,
      payload,
      active: true
    });

    notifyStaleLicenseHelpDeskResult(request.requesterTabId, {
      requestId,
      ok: true,
      helpDeskRequestId: draftResult.requestId,
      helpdeskTabId: draftResult.tabId
    });
  } catch (openError) {
    await cleanupHelpDeskDraftAttachments(payload);
    notifyStaleLicenseHelpDeskResult(request.requesterTabId, {
      requestId,
      ok: false,
      error: openError?.message || 'Не вдалося відкрити чернетку HelpDeskEddy.'
    });
  }
}

async function openHealthPeriodTab({ requesterTabId, server, port, requestId }) {
  const credentialSet = await fetchSyrveCredentials();
  const createdTab = await chrome.tabs.create({
    url: buildSyrvePageUrl({
      server,
      port,
      path: '/resto/service/monitoring/health.jsp'
    }),
    active: false
  });

  if (createdTab.id === undefined) {
    throw new Error('Health tab was created without an id');
  }

  const timeoutId = setTimeout(() => {
    finalizeHealthPeriodRequest(createdTab.id, {
      error: 'Перевищено час очікування відповіді від сторінки health.jsp.'
    });
  }, HEALTH_PERIOD_TIMEOUT_MS);

  HEALTH_PERIOD_REQUESTS.set(createdTab.id, {
    requesterTabId,
    requestId,
    timeoutId
  });

  cacheSyrveCredentialsForTab(createdTab.id, credentialSet);

  log.info('Opened health period tab', {
    requesterTabId,
    serviceTabId: createdTab.id,
    server,
    port,
    requestId
  });

  return createdTab.id;
}

function clearConnectionsSnapshotRequest(serviceTabId) {
  const request = CONNECTIONS_SNAPSHOT_REQUESTS.get(serviceTabId);
  if (!request) {
    return null;
  }

  CONNECTIONS_SNAPSHOT_REQUESTS.delete(serviceTabId);
  clearTimeout(request.timeoutId);
  clearSyrveCredentialsForTab(serviceTabId);
  return request;
}

function buildConnectionsSnapshotRequestKey(requesterTabId, requestId) {
  return `${requesterTabId}:${requestId}`;
}

async function openConnectionsSnapshotTab({
  requesterTabId,
  server,
  port,
  requestId,
  connectionsHelpDeskPayload = null
}) {
  const requestKey = buildConnectionsSnapshotRequestKey(requesterTabId, requestId);
  const credentialSet = await fetchSyrveCredentials();
  if (CANCELLED_CONNECTIONS_SNAPSHOT_REQUESTS.delete(requestKey)) {
    throw new Error('Запит отримання зайнятих ліцензій скасовано.');
  }
  const pageUrl = buildSyrvePageUrl({
    server,
    port,
    path: CONNECTIONS_PATH
  });
  const createdTab = await chrome.tabs.create({
    url: 'about:blank',
    active: false
  });

  if (createdTab.id === undefined) {
    throw new Error('Connections snapshot tab was created without an id');
  }

  if (CANCELLED_CONNECTIONS_SNAPSHOT_REQUESTS.delete(requestKey)) {
    await chrome.tabs.remove(createdTab.id).catch(() => {});
    throw new Error('Запит отримання зайнятих ліцензій скасовано.');
  }

  const serviceTabId = createdTab.id;
  const timeoutId = setTimeout(() => {
    finalizeConnectionsSnapshotRequest(serviceTabId, {
      error: 'Сервер не повернув таблицю зайнятих ліцензій за 30 секунд.'
    });
  }, CONNECTIONS_SNAPSHOT_TIMEOUT_MS);

  CONNECTIONS_SNAPSHOT_REQUESTS.set(serviceTabId, {
    requesterTabId,
    requestId,
    timeoutId,
    server,
    port,
    pageUrl
  });
  cacheSyrveCredentialsForTab(serviceTabId, credentialSet);

  try {
    if (connectionsHelpDeskPayload && typeof connectionsHelpDeskPayload === 'object') {
      await storeConnectionsHelpDeskContext(serviceTabId, connectionsHelpDeskPayload, {
        server,
        port,
        path: CONNECTIONS_PATH,
        url: pageUrl
      });
    }
    await chrome.tabs.update(serviceTabId, { url: pageUrl, active: false });
  } catch (error) {
    clearConnectionsSnapshotRequest(serviceTabId);
    await chrome.tabs.remove(serviceTabId).catch(() => {});
    throw error;
  }

  log.info('Opened background Syrve connections snapshot tab', {
    requesterTabId,
    serviceTabId,
    server,
    port,
    requestId
  });

  return serviceTabId;
}

async function runConnectionsSnapshotStaleAction(requesterTabId, requestId) {
  const entry = Array.from(CONNECTIONS_SNAPSHOT_REQUESTS.entries()).find(([, request]) => (
    request.requesterTabId === requesterTabId && request.requestId === requestId
  ));
  if (!entry) {
    throw new Error('Фонове оновлення таблиці вже зупинено. Відкрийте список ліцензій ще раз.');
  }

  const [serviceTabId] = entry;
  const deadline = Date.now() + 3000;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const response = await chrome.tabs.sendMessage(serviceTabId, {
        action: 'RUN_STALE_LICENSE_ACTION'
      });
      if (response?.ok) {
        return {
          serviceTabId,
          mode: response.mode || ''
        };
      }
      throw new Error(response?.error || 'Дія для завислих ліцензій недоступна.');
    } catch (error) {
      lastError = error;
      if (!String(error?.message || '').includes('Receiving end does not exist')) {
        throw error;
      }
    }

    await waitForDelay(150);
  }

  throw lastError || new Error('Не вдалося запустити дію для завислих ліцензій.');
}

async function cancelConnectionsSnapshotRequest(requesterTabId, requestId) {
  const entry = Array.from(CONNECTIONS_SNAPSHOT_REQUESTS.entries()).find(([, request]) => (
    request.requesterTabId === requesterTabId && request.requestId === requestId
  ));

  if (!entry) {
    CANCELLED_CONNECTIONS_SNAPSHOT_REQUESTS.add(buildConnectionsSnapshotRequestKey(requesterTabId, requestId));
    return true;
  }

  const [serviceTabId] = entry;
  clearConnectionsSnapshotRequest(serviceTabId);
  await chrome.tabs.remove(serviceTabId).catch(() => {});
  return true;
}

async function cancelConnectionsSnapshotRequestsByRequesterTabId(requesterTabId) {
  const serviceTabIds = Array.from(CONNECTIONS_SNAPSHOT_REQUESTS.entries())
    .filter(([, request]) => request.requesterTabId === requesterTabId)
    .map(([serviceTabId]) => serviceTabId);

  serviceTabIds.forEach((serviceTabId) => {
    clearConnectionsSnapshotRequest(serviceTabId);
  });

  await Promise.all(serviceTabIds.map((serviceTabId) => chrome.tabs.remove(serviceTabId).catch(() => {})));
}

async function openSyrvePage({ server, path, port, active = true, connectionsHelpDeskPayload = null }) {
  const credentialSet = await fetchSyrveCredentials();
  const pageUrl = buildSyrvePageUrl({ server, port, path });
  const createdTab = await chrome.tabs.create({
    url: pageUrl,
    active
  });

  if (createdTab.id === undefined) {
    throw new Error('Syrve tab was created without an id');
  }

  cacheSyrveCredentialsForTab(createdTab.id, credentialSet);
  if (isConnectionsPath(path) && connectionsHelpDeskPayload && typeof connectionsHelpDeskPayload === 'object') {
    await storeConnectionsHelpDeskContext(createdTab.id, connectionsHelpDeskPayload, {
      server,
      port,
      path,
      url: pageUrl
    });
  }

  log.info('Opened Syrve page after credentials preflight', {
    serviceTabId: createdTab.id,
    server,
    port,
    path,
    active
  });

  return createdTab.id;
}

async function openLoyaltyPage({ login, active = true }) {
  const credential = {
    login: normalizeLoyaltyLogin(login),
    password: LOYALTY_PASSWORD
  };
  const createdTab = await chrome.tabs.create({
    url: LOYALTY_PAGE_URL,
    active
  });

  if (createdTab.id === undefined) {
    throw new Error('Loyalty tab was created without an id');
  }

  cacheLoyaltyCredentialsForTab(createdTab.id, credential);
  log.info('Opened Loyalty page with tab-scoped credentials', {
    serviceTabId: createdTab.id,
    active
  });

  return createdTab.id;
}

async function openCrmHandoff({ syrveWebUrl, active = true }) {
  const url = await fetchCrmHandoffUrl({ syrveWebUrl });
  const createdTab = await chrome.tabs.create({
    url,
    active
  });

  if (createdTab.id === undefined) {
    throw new Error('CRM handoff tab was created without an id');
  }

  log.info('Opened CRM handoff URL', {
    serviceTabId: createdTab.id,
    syrveWebUrl: normalizeCrmHandoffSyrveWebUrl(syrveWebUrl),
    active
  });

  return {
    tabId: createdTab.id,
    url
  };
}

async function openCardWebUrlWithSyrveCredentials({ url, active = true }) {
  const credentialSet = await fetchSyrveCredentials();
  const normalizedUrl = normalizeCardWebUrl(url);
  const createdTab = await chrome.tabs.create({
    url: normalizedUrl,
    active
  });

  if (createdTab.id === undefined) {
    throw new Error('Web tab was created without an id');
  }

  cacheSyrveCredentialsForTab(createdTab.id, credentialSet);
  log.info('Opened card web URL tab with tab-scoped Syrve credentials', {
    serviceTabId: createdTab.id,
    url: normalizedUrl,
    active
  });

  return createdTab.id;
}

function finalizeHealthPeriodRequest(serviceTabId, result) {
  const request = HEALTH_PERIOD_REQUESTS.get(serviceTabId);
  if (!request) {
    return;
  }

  HEALTH_PERIOD_REQUESTS.delete(serviceTabId);
  clearTimeout(request.timeoutId);
  clearSyrveCredentialsForTab(serviceTabId);

  notifyHealthPeriodResult(request.requesterTabId, {
    requestId: request.requestId,
    period: result.period,
    periodStartDate: result.periodStartDate,
    version: result.version,
    versionRaw: result.versionRaw,
    error: result.error
  });

  chrome.tabs.remove(serviceTabId).catch((error) => {
    log.debug('Health period tab already closed', { serviceTabId, error: error?.message });
  });
}

function notifyHealthPeriodResult(requesterTabId, payload) {
  chrome.tabs.sendMessage(requesterTabId, {
    action: 'HEALTH_PERIOD_RESULT',
    ...payload
  }).catch((error) => {
    log.warn('Failed to deliver health period result to PlanFix tab', {
      requesterTabId,
      error: error?.message
    });
  });
}

function finalizeConnectionsSnapshotRequest(serviceTabId, result) {
  const request = clearConnectionsSnapshotRequest(serviceTabId);
  if (!request) {
    return;
  }

  notifyConnectionsSnapshotResult(request.requesterTabId, {
    requestId: request.requestId,
    snapshot: result?.snapshot,
    error: result?.error
  });

  chrome.tabs.remove(serviceTabId).catch((error) => {
    log.debug('Connections snapshot tab already closed', { serviceTabId, error: error?.message });
  });
}

function forwardConnectionsSnapshotResult(serviceTabId, result) {
  const request = CONNECTIONS_SNAPSHOT_REQUESTS.get(serviceTabId);
  if (!request) {
    return;
  }

  if (result?.error) {
    finalizeConnectionsSnapshotRequest(serviceTabId, result);
    return;
  }

  clearTimeout(request.timeoutId);
  request.timeoutId = setTimeout(() => {
    finalizeConnectionsSnapshotRequest(serviceTabId, {
      error: 'Оновлення таблиці зайнятих ліцензій зупинилося більш ніж на 30 секунд.'
    });
  }, CONNECTIONS_SNAPSHOT_TIMEOUT_MS);

  notifyConnectionsSnapshotResult(request.requesterTabId, {
    requestId: request.requestId,
    snapshot: result?.snapshot,
    streaming: true
  });
}

function notifyConnectionsSnapshotResult(requesterTabId, payload) {
  chrome.tabs.sendMessage(requesterTabId, {
    action: 'CONNECTIONS_SNAPSHOT_RESULT',
    ...payload
  }).catch((error) => {
    log.warn('Failed to deliver Syrve connections snapshot to PlanFix tab', {
      requesterTabId,
      error: error?.message
    });
  });
}

function notifyConnectionsStaleActionState(requesterTabId, payload) {
  chrome.tabs.sendMessage(requesterTabId, {
    action: 'CONNECTIONS_STALE_ACTION_STATE',
    ...payload
  }).catch((error) => {
    log.warn('Failed to deliver stale license action state to PlanFix tab', {
      requesterTabId,
      error: error?.message
    });
  });
}
